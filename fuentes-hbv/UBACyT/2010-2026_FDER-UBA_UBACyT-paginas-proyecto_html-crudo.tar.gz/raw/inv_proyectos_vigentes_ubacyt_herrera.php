
<!DOCTYPE html>
<html lang="es">
<head>
    
    

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="author" content="kame-code.com">
<meta name="robots" content="index,follow">

<meta property="og:image" content="/img/logo/logo-media.png">
<meta property="og:image:type" content="image/png">
<meta property="og:image:width" content="363">
<meta property="og:image:height" content="363">

<!-- Mobile Specific Meta Tag-->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<!-- X TWITTER-->

<!-- Favicon and Apple Icons-->
<link rel="apple-touch-icon" sizes="57x57" href="/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon/favicon-16x16.png">
<link rel="manifest" href="/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<!-- Web Fonts  -->
<link id="googleFonts" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800%7CShadows+Into+Light&display=swap" rel="stylesheet" type="text/css">

<!-- Vendor CSS -->
<link rel="stylesheet" href="/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/vendor/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="/vendor/animate/animate.compat.css">
<link rel="stylesheet" href="/vendor/simple-line-icons/css/simple-line-icons.min.css">
<link rel="stylesheet" href="/vendor/owl.carousel/assets/owl.carousel.min.css">
<link rel="stylesheet" href="/vendor/owl.carousel/assets/owl.theme.default.min.css">
<link rel="stylesheet" href="/vendor/magnific-popup/magnific-popup.min.css">

<!-- Theme CSS -->
<link rel="stylesheet" href="/css/theme.css">
<link rel="stylesheet" href="/css/theme-elements.css">
<link rel="stylesheet" href="/css/theme-blog.css">
<link rel="stylesheet" href="/css/theme-shop.css">

<!-- Skin CSS -->
<link id="skinCSS" rel="stylesheet" href="/css/skins/derecho.css">

<!-- Theme Custom CSS -->
<link rel="stylesheet" href="/css/custom.css?1682693634">

<!-- Head Libs -->
<script src="/vendor/modernizr/modernizr.min.js"></script>

<base href="https://www.derecho.uba.ar" />
    <meta name="description" content="Facultad de Derecho de la Universidad de Buenos Aires">
    <title>Proyectos UBACyT - Investigaci&oacute;n | Facultad de Derecho - Universidad de Buenos Aires</title>

</head>
<body class="cbp-spmenu-push" data-plugin-page-transition data-plugin-scroll-spy data-plugin-options="{'target': '#sidebar'}">
    <div class="body">
        <header id="header" class="header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': false, 'stickyChangeLogo': true, 'stickyStartAt': 30, 'stickyHeaderContainerHeight': 52}">
    <div class="header-body border-top-0">
        <div class="header-top">
            <div class="container">
                <div class="header-row py-md-2">
                    <div id="header-top-column" class="header-column justify-content-start">
                        <div class="header-row">
                            <nav id="header-nav-top" class="header-nav-top">
                                <ul class="nav nav-pills text-3">
                                    <li class="nav-item">
                                        <a class="nav-link ps-0 text-secondary" title="Información para ingresantes de la Facultad de Derecho" href="/ingresantes">
                                            Ingresantes
                                        </a>
                                    </li>
                                    <li class="nav-item nav-item-left-border">
                                        <a class="nav-link pe-0 text-secondary" title="Estudiantes de la Facultad de Derecho" href="/estudiantes">
                                            Estudiantes
                                        </a>
                                    </li>
                                    <li class="nav-item nav-item-left-border">
                                        <a class="nav-link ps-0 text-secondary" title="Docentes de la Facultad de Derecho" href="/docentes">
                                            Docentes
                                        </a>
                                    </li>
                                    <li class="nav-item nav-item-left-border">
                                        <a class="nav-link ps-0 text-secondary" title="Graduados de la Facultad de Derecho" href="/graduados">
                                            <span class="d-none d-sm-inline">Graduadas/os</span>
                                            <span class="d-inline d-sm-none">Graduadas</span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="header-column justify-content-end">
                        <div class="header-row">
                            <nav class="header-nav-top">
                                <ul class="nav nav-pills text-uppercase text-2">
                                  <li class="nav-item nav-item-anim-icon d-none d-md-block"><a class="nav-link pe-0" href="https://3w.derecho.uba.ar/" target="_blank">
                                      <i class="fas fa-angle-right"></i>
                                      SIU-Guaraní
                                  </a>                                  </li>
                                </ul>
                            </nav>
                            <div class="header-nav-features d-none d-md-block">
                                <div class="header-nav-features-search-reveal-container">
                                    <div class="header-nav-feature header-nav-features-search header-nav-features-search-reveal d-inline-flex">
                                        <a href="#" class="header-nav-features-search-show-icon d-inline-flex text-decoration-none"><i class="fas fa-search header-nav-top-icon"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="header-row">
                    <div class="header-nav-features header-nav-features-no-border p-static z-index-2">
                        <div class="header-nav-feature header-nav-features-search header-nav-features-search-reveal header-nav-features-search-reveal-big-search px-3">
                            <form role="search" class="d-flex w-100 h-100" action="/index_resbus.php" method="get" accept-charset="utf-8">
                                <div class="big-search-header input-group">
                                    <input class="form-control text-1" name="q" type="search" value="" placeholder="Buscar...">
                                    <input type="hidden" name="cx" value="007910097264156725590:4u2nbtj2ado">
                                    <input type="hidden" name="cof" value="FORID:11">
                                    <input type="hidden" name="ie" value="utf-8">
                                    <a href="#" class="header-nav-features-search-hide-icon"><i class="fas fa-times header-nav-top-icon"></i></a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-container container d-none d-md-flex">
            
            <div class="header-row">
                <div class="header-column justify-content-start justify-content-md-center order-1 order-md-2">
                    <div class="header-row">
                        <div class="header-logo justify-content-center">
                            <a href="/" title="Facultad de Derecho de la Universidad de Buenos Aires">
                                <img alt="Facultad de Derecho" width="371" height="52" data-sticky-width="307" data-sticky-height="43" src="/img/logo-header.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-nav-bar header-nav-bar-top-border">
            <div class="header-container container">
                <div class="header-row">
                    <div class="header-column justify-content-center d-flex d-md-none">
                        <a href="/" title="Facultad de Derecho de la Universidad de Buenos Aires">
                            <img alt="Facultad de Derecho" width="220" src="/img/logo-header.png">
                        </a>
                    </div>
                    <div class="header-column">
                        <div class="header-row justify-content-end">
                            <div class="header-nav p-0">
                                <div class="header-nav header-nav-links justify-content-lg-center">
                                    <div class="header-nav-main header-nav-main-square header-nav-main-dropdown-no-borders header-nav-main-dropdown-arrow header-nav-main-dropdown-center header-nav-main-dropdown-center-bottom header-nav-main-effect-3 header-nav-main-sub-effect-1">
                                        <nav class="collapse">
                                            <ul class="nav nav-pills" id="mainNav">
                                                <li><a href="/institucional">Institucional</a></li>
                                                <li><a href="/academica">Académica</a></li>
                                                <li><a href="/investigacion">Investigación</a></li>
                                                <li><a href="/extension">Extensión</a></li>
                                                <li><a href="/internacionales">Internacionales</a></li>
                                                <li><a href="/publicaciones">Publicaciones</a></li>
                                                <li><a href="/biblioteca">Biblioteca</a></li>
                                                <li><a href="/academica/posgrados">Posgrado</a></li>
                                            </ul>
                                            <div class="d-lg-none">        
                                                <form role="search" action="/index_resbus.php" id="cse-search-box" accept-charset="utf-8">
                                                    <div class="simple-search input-group">
                                                        <input class="form-control text-1" id="headerSearch" name="q" type="search" value="" placeholder="Buscar...">
                                                        <input type="hidden" name="cx" value="007910097264156725590:4u2nbtj2ado">
                                                        <input type="hidden" name="cof" value="FORID:11">
                                                        <input type="hidden" name="ie" value="utf-8">
                                                        <button class="btn" type="submit"> <i class="fas fa-search header-nav-top-icon text-color-dark"></i> </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </nav>
                                    </div>
                                    <button class="btn header-btn-collapse-nav" data-bs-toggle="collapse" data-bs-target=".header-nav-main nav">
                                        <i class="fas fa-bars"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="header-nav-features header-nav-features-no-border header-nav-features-lg-show-border order-1 order-lg-2">
                        <div class="header-nav-feature header-nav-features-search d-inline-flex">
                            <a href="#" class="header-nav-features-toggle text-decoration-none show-menu d-show d-md-none">
                                <span class="fa fa-outdent"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
        <main role="main" class="main">
            <nav id="menu-offcanvas" class="cbp-spmenu">
                <!-- Contenido Dinámico - No remover -->
            </nav>

            <section class="page-header page-header-modern bg-color-light-scale-1 page-header-sm">
                <div class="container">
                    <div class="row">
                        <div class="col-12 align-self-center">
                            <ul class="breadcrumb d-block">
                                
                <li><a href="index.php">Inicio</a></li><li><a href="/investigacion/">Investigacion</a></li><li><a href="investigacion/inv_proyectos_vigentes.php">Proyectos de Investigaci&oacute;n vigentes</a></li><li><a href="investigacion/inv_prog_ubacyt.php">Proyectos UBACyT 2010-2012</a></li><li><a href="investigacion/en-inv_proyectos_vigentes_ubacyt_herrera.php" title="information for foreigners">English version</a></li>
            
                            </ul>
                        </div>
                    </div>
                </div>
            </section>

            <div class="container my-3">
                <div class="row py-3">
                    <div class="col-lg-3 position-relative d-none d-lg-flex">
                        <nav class="sidebar" id="sidebar" data-plugin-sticky data-plugin-options="{'minWidth': 991, 'containerSelector': '.container', 'padding': {'top': 130}}">
                            <h5 class="font-weight-semi-bold">
                                Investigaci&oacute;n
                                <span class="fa fa-2x fa-times d-none hide-menu"></span>
                            </h5>
                            
                            
                    <ul class="nav nav-list flex-column mb-5"><li class="nav-item"><a href="investigacion/inv_institutos.php" class="nav-link">Institutos de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_proyectos_vigentes.php" class="nav-link">Proyectos de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_becarios.php" class="nav-link">Becarios/as de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_programas_estudiantes.php" class="nav-link">Programas para estudiantes</a></li>
<li class="nav-item"><a href="investigacion/inv_programas_docentes_investigadores.php" class="nav-link">Programas para docentes-investigadores/as</a></li>
<li class="nav-item"><a href="investigacion/investigacion_investigadores_visitantes.php" class="nav-link">Investigadores/as visitantes</a></li>
<li class="nav-item"><a href="investigacion/agenda/" class="nav-link">Agenda</a></li>
<li class="nav-item"><a href="investigacion/noticias/" class="nav-link">Noticias</a></li>
</ul><h5 class=" text-2 pt-4">Contacto</h5>
    <ul class="list list-icons list-icons-style-2 mt-2">
        <li><i class="fas fa-map-marker-alt top-6"></i>Primer Piso</li>
        <li><i class="fas fa-clock top-6"></i>Lunes a viernes 10 a 20 hs (atención telefónica) - Lunes a viernes 10 a 19 hs (atención presencial)</li>
        <li><i class="fas fa-phone top-6"></i> (5411) 5287-7096</li>
        <li><i class="fas fa-envelope top-6"></i> <a href="mailto:investigacion@derecho.uba.ar">investigacion@derecho.uba.ar</a></li>
    </ul>
<h5 class="text-2 pt-4">Redes</h5>
    <ul class="social-icons">
        <li class="social-icons-twitter"><a href="http://twitter.com/SI_DerechoUBA  " target="_blank"><i class="fab fa-twitter"></i></a></li>
        <li class="social-icons-instagram"><a href="https://www.instagram.com/si_derechouba/  " target="_blank"><i class="fab fa-instagram"></i></a></li>
        <li class="social-icons-youtube"><a href="https://www.youtube.com/channel/UCFz7MFrOGcFxkQbrItItzTw  " target="_blank"><i class="fab fa-youtube"></i></a></li>
    </ul>                
                            
                        </nav>
                    </div>
                    <div class="col-lg-9 contenido_pagina-col2">
                        
                
   <h1>Proyectos UBACyT</h1>
   <h3>Fecha de inicio </h3>
   <p class="tabulado">1&ordm; de julio de 2011</p>
   <h3>Fecha de finalizaci&oacute;n </h3>
   <p class="tabulado">30 de junio de 2013</p>
   <h3>C&oacute;digo </h3>
   <p class="tabulado">20020100200050</p>
   <h3>Tipo de proyecto </h3>
   <p class="tabulado">Grupo en formaci&oacute;n</p>
   <h3>T&iacute;tulo</h3>
   <p class="tabulado">Hacia una regulaci&oacute;n de la procreaci&oacute;n asistida desde la perspectiva socio jur&iacute;dica. Bio&eacute;tica y Derechos Humanos.</p>
   <h3>Directora</h3>
   <p class="tabulado"> Marisa Herrera</p>
   <h3>Contacto</h3>
   <p class="tabulado"><a href="mailto:gioja@derecho.uba.ar">gioja@derecho.uba.ar</a></p>
   <p>&nbsp;</p>
   <div class="table-responsive"><table class="table table-striped table-bordered"><thead><tr class="celeste">
         <th colspan="3" align="center"><strong>INTEGRANTES</strong></th>
        </tr></thead><tbody><tr>
         <td align="center" valign="middle" width="13%"><strong>N&deg;</strong></td>
         <td align="center" valign="middle" width="40%"><strong>Nombre y apellido</strong></td>
         <td align="center" width="47%"><strong>Categor&iacute;a</strong></td>
        </tr><tr>
         <td align="center" valign="middle">1 </td>
         <td align="center" valign="middle">Mart&iacute;n Miguel Culaciati <br></td>
         <td align="center">Investigador tesista</td>
        </tr><tr>
         <td align="center" valign="middle">2</td>
         <td align="center" valign="middle"> Diego Hern&aacute;n Flores</td>
         <td align="center"> Investigador tesista</td>
       </tr><tr>
         <td align="center" valign="middle">3</td>
         <td align="center" valign="middle"> Rosalia Ver&oacute;nica Mu&ntilde;oz Genestoux</td>
         <td align="center">Investigadora tesista</td>
       </tr><tr>
         <td align="center" valign="middle">4</td>
         <td align="center" valign="middle"> Mariana Rodr&iacute;guez Iturburu<br></td>
         <td align="center">Investigadora tesista</td>
       </tr><tr>
         <td align="center" valign="middle">5</td>
         <td align="center" valign="middle">Silvia Noem&iacute; Gramigni</td>
         <td align="center">Investigadora en formaci&oacute;n</td>
       </tr><tr>
         <td align="center" valign="middle">6</td>
         <td align="center" valign="middle"> Clara Mar&iacute;a Romero</td>
         <td align="center">Investigadora en formaci&oacute;n</td>
       </tr><tr>
         <td align="center" valign="middle">7</td>
         <td align="center" valign="middle"> Natalia De La Torre</td>
         <td align="center"> Investigadora estudiante</td>
       </tr><tr>
         <td align="center" valign="middle">8</td>
         <td align="center" valign="middle">Silvia Carolina Cruz </td>
         <td align="center">Colaboradora externa</td>
       </tr><tr>
         <td align="center" valign="middle">9</td>
         <td align="center" valign="middle"> Mar&iacute;a Cecilia Cardella</td>
         <td align="center"> Investigadora estudiante</td>
       </tr><tr>
         <td align="center" valign="middle">10</td>
         <td align="center" valign="middle"> Nicol&aacute;s Alejandro Moncada</td>
         <td align="center"> Investigador estudiante</td>
       </tr><tr>
         <td align="center" valign="middle">11</td>
         <td align="center" valign="middle"> Marianela Lourdes Germian</td>
         <td align="center"> Investigadora estudiante</td>
       </tr><tr>
         <td align="center" valign="middle">12</td>
         <td align="center" valign="middle"> Carla Jorgelina Crovetto</td>
         <td align="center"> Investigadora estudiante</td>
       </tr>
       <tr>
         <td align="center" valign="middle">13</td>
         <td align="center" valign="middle">Agustina Perez</td>
         <td align="center">&nbsp;</td>
       </tr>
       <tr>
         <td align="center" valign="middle">14</td>
         <td align="center" valign="middle">Agustina Bladilo</td>
         <td align="center">&nbsp;</td>
       </tr>
       <tr>
         <td align="center" valign="middle">15</td>
         <td align="center" valign="middle">Federico Vicente</td>
         <td align="center">&nbsp;</td>
       </tr>
       <tr>
         <td align="center" valign="middle">16</td>
         <td align="center" valign="middle">Eduardo Sabin Paz</td>
         <td align="center">&nbsp;</td>
       </tr>
       <tr>
         <td align="center" valign="middle">17</td>
         <td align="center" valign="middle">Gaston Argeri</td>
         <td align="center">&nbsp;</td>
       </tr>
       <tr>
         <td align="center" valign="middle">18</td>
         <td align="center" valign="middle">           Mariana Vazquez Acatto</td>
         <td align="center">&nbsp;</td>
       </tr>
       </tbody></table></div>
   <p><strong>PALABRAS CLAVE</strong></p>
   <p class="tabulado">Procreaci&oacute;n asistida <br>
    Bio&eacute;tica <br>
    Derechos Humanos </p>
   <p><strong>    RESUMEN</strong></p>
   <p class="tabulado">Este proyecto de car&aacute;cter socio jur&iacute;dico -siguiendo la l&iacute;nea de investigaci&oacute;n que desarrolla hace varios a&ntilde;os Cecilia Grosman en el derecho de familia- pretende culminar con la elaboraci&oacute;n de un proyecto de ley que regule el uso de las t&eacute;cnicas de procreaci&oacute;n asistida (TPA), teni&eacute;ndose en cuenta los avances, pr&aacute;cticas y prejuicios que se observan en diferentes &aacute;mbitos del saber; en particular, en la medicina y la psicolog&iacute;a nucleados por el vertiginoso desarrollo de la Bio&eacute;tica. Se utilizar&aacute;n diferentes fuentes de informaci&oacute;n, tanto primarias como secundarias, destac&aacute;ndose el desarrollo legislativo y jurisprudencial que observa el derecho comparado &ndash;en especial, el europeo y anglosaj&oacute;n- mostrando una amplia diversidad en las l&iacute;neas que se siguen. Se llevar&aacute;n adelante algunas indagaciones de campo tendientes a conocer el perfil de los usuarios de las TPA, entre otros datos sociales de relevancia para que el proyecto de ley que se dise&ntilde;e tenga en cuenta e incluso fundar sus lineamientos, seg&uacute;n lo que acontece en la realidad. Permitir el uso de material gen&eacute;tico de terceros &ndash;an&oacute;nimos o no- a quienes tienen la voluntad de ser padres (la mal llamada fertilizaci&oacute;n &ldquo;heter&oacute;loga&rdquo;); o cuestiones m&aacute;s &ldquo;sensibles&rdquo; como la &ldquo;maternidad subrogada&rdquo;, son s&oacute;lo algunas de las tantas cuestiones que coloca en &ldquo;crisis&rdquo; a una de las instituciones cl&aacute;sicas del derecho de familia como lo es la filiaci&oacute;n. &iquest;C&oacute;mo es la determinaci&oacute;n de la filiaci&oacute;n cuando &eacute;sta se deriva del uso de las t&eacute;cnicas de procreaci&oacute;n asistida, teni&eacute;ndose en cuenta sus distintas modalidades? &iquest;C&oacute;mo juega en el derecho filial la &ldquo;voluntad procreacional&rdquo;, columna vertebral de las TPA? Esta cuesti&oacute;n, como tantas otras que involucra el tema (incluso, pertenecientes a otras ramas del derecho como el derecho administrativo, derecho de da&ntilde;os y el derecho penal en lo relativo al rol de los establecimientos m&eacute;dicos), habr&iacute;an sido abordadas de manera parcializadas en la doctrina y algunos proyectos de investigaci&oacute;n, sin arribarse a conclusiones concretas como impone la elaboraci&oacute;n de un proyecto de ley integral. Una construcci&oacute;n de este tenor implica un an&aacute;lisis t&eacute;cnico- jur&iacute;dico bien complejo, cuya importancia se habr&iacute;a acelerado tras la sanci&oacute;n de la ley 26.618 de matrimonio igualitario. En definitiva, el tema propuesto permite continuar profundizando sobre la noci&oacute;n de familia en el derecho contempor&aacute;neo a la luz de la obligada doctrina internacional de los Derechos Humanos. </p>
   <p><strong>MODALIDAD DE TRABAJO</strong></p>
   <p>Este proyecto de investigaci&oacute;n se desarrolla en el &aacute;rea del Derecho Privado, m&aacute;s espec&iacute;ficamente, en el &aacute;mbito del derecho de familia, tendiente a redise&ntilde;ar instituciones jur&iacute;dicas a la luz de los nuevos avances cient&iacute;ficos en las t&eacute;cnicas de reproducci&oacute;n humana asistida, tom&aacute;ndose como punto partida las implicancias y tensiones de la doctrina internacional de los derechos humanos.</p>
   <p>     En plenos aires de reforma de la ley civil, el tema de las t&eacute;cnicas de reproducci&oacute;n humana asistida ha generado un gran inter&eacute;s, lo cual no s&oacute;lo afirma la pertinencia y actualidad del tema, sino tambi&eacute;n la necesidad de indagar sobre su regulaci&oacute;n desde la obligada perspectiva de Derechos Humanos. </p>
   <p>     Dado el car&aacute;cter interdisciplinario del tema en estudio, el proyecto de investigaci&oacute;n se enmarca dentro de una metodolog&iacute;a de investigaci&oacute;n sociojur&iacute;dica tendiente a integrar las diferentes &aacute;reas y actores sociales que confluyen en un tema perteneciente a la bio&eacute;tica, teniendo por finalidad acortar la brecha existente entre Derecho y Realidad y elaborar, como producto final, un Proyecto de Ley integral de T&eacute;cnicas de Reproducci&oacute;n Humana asistida que lo permita.</p>
   <p>     La investigaci&oacute;n se ha divido en dos l&iacute;neas de trabajo, la primera fundamentalmente te&oacute;rica &ndash; sobre la cual ha habido un gran desarrollo- (a), la segunda, eminentemente pr&aacute;ctica, en pleno proceso de elaboraci&oacute;n (b):</p>
   <p>     a) Trabajos de indagaci&oacute;n te&oacute;rica: investigaci&oacute;n documental y bibliogr&aacute;fica sobre diferentes experiencias que se observan en el derecho comparado, an&aacute;lisis de la regulaci&oacute;n proyectada en la Reforma del C&oacute;digo Civil sobre filiaci&oacute;n en el caso de uso de t&eacute;cnicas de reproducci&oacute;n humanan asistida, an&aacute;lisis de los proyectos de ley presentados en el Congreso de la Naci&oacute;n sobre cobertura de los tratamientos por los Sistemas de Salud &ndash;p&uacute;blicos y privados-, b&uacute;squeda de jurisprudencia relacionada con la tem&aacute;tica en el &aacute;mbito internacional y an&aacute;lisis de los escasos planteos jurisprudenciales que observa el derecho nacional.</p>
   <p>     b) Trabajo de campo: a su vez, la labor pr&aacute;ctica ha estado centrada en recabar la opini&oacute;n y experiencia de aquellas personas involucradas en forma directa en el uso de estas t&eacute;cnicas: los profesionales especialistas en TRHA- m&eacute;dicos, psic&oacute;logos, abogados- y los usuarios, destinatarios de las mismas. Para acceder a dicha informaci&oacute;n se han confeccionado instrumentos de captaci&oacute;n diversos. As&iacute;, para el caso de los profesionales o especialistas en TRHA se confeccion&oacute; una encuesta semi-estructurada que sirve de gu&iacute;a a la hora de entrevistar a los distintos operadores. A las entrevistas concurren entre tres o cuatro integrantes del proyecto de investigaci&oacute;n &ndash;van variando-, duran aproximadamente una hora u hora y media y son grabadas con autorizaci&oacute;n de los entrevistados. Luego, ese material es desgravado &ndash;pasado a formato texto- por alguno de los integrantes del grupo para su difusi&oacute;n y an&aacute;lisis con los dem&aacute;s integrantes del equipo. En cambio, en el caso de las personas que son o han sido usuarios de estas t&eacute;cnicas se prefiri&oacute; optar por otro instrumento, una encuesta con cincuentaicinco preguntas que permiten a los usuarios de forma an&oacute;nima brindar informaci&oacute;n sobre su experiencia luego de pasar o estar atravesando algunas de las etapas que conllevan la realizaci&oacute;n de estos tratamientos. De esta forma, se pretende conocer cu&aacute;les son los miedos reales, las preocupaciones y las tensiones que generan estas pr&aacute;cticas en sus destinatarios, los usuarios, a trav&eacute;s de distintas variables &ndash;acceso a las TRHA, donaci&oacute;n de gametos, gestaci&oacute;n por sustituci&oacute;n, derecho a conocer los or&iacute;genes, etc.-. Cada integrante del equipo de investigaci&oacute;n realiza las encuestas de forma individual y luego las vuelca en una planilla general &ndash;formato Excel- con el fin de unificar el formato, facilitar la lectura de los resultados y procesar los tabulados una vez que se encuentren todas las encuestas ingresadas. Cada encuesta se realiza en aproximadamente treinta minutos, dependiendo de la extensi&oacute;n de las respuestas por parte de los encuestados. </p>
   <p>Por &uacute;ltimo, cabe destacar en esta breve descripci&oacute;n la din&aacute;mica plural con la que se concibe y se trabaja en el Proyecto, empezando por la diversidad de ocupaciones de las personas que lo integran. El grupo est&aacute; encabezado por su Directora, Marisa Herrera, Doctora en Derecho, docente semi-exclusiva de esta casa de estudio, investigadora del Conicet, acompa&ntilde;ada en esta labor por abogados dedicados al ejercicio de la profesi&oacute;n, profesionales que est&aacute;n en plena elaboraci&oacute;n de su tesis de maestr&iacute;a, docentes de la Facultad, abogados recientemente recibidos y alumnos adscriptos al proyecto.</p>
   <p><strong>CARGA HORARIA</strong></p>
   <p>     El equipo de investigaci&oacute;n organiza reuniones con una periodicidad mensual en la que participan todos los integrantes y donde se ponen sobre la mesa los avances de la investigaci&oacute;n, las cuestiones pendientes y las pautas de trabajo futura.<br>
   </p>

            
                    </div>
                </div>
            </div>
        </main>
    </div>

    <footer id="footer">
    <div class="container">
        <div class="row py-5">
            <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
                <h5 class="text-3 mb-3 text-upper">Accesos directos</h5>
                <ul class="list list-icons list-icons-sm">
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/institucional/consejo-directivo/">Consejo Directivo</a></p>
                    </li>
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/institucional/deinteres/informes-de-gestion.php">Informes de gestión</a></p>
                    </li>
                    <li class="mb-1"> <i class="fa fa-chevron-right text-color-primary"></i>
                      <p class="m-0"><a href="/internacionales/programas-de-intercambio-estudiantil.php">Programas de intercambio estudiantil</a></p>
                    </li>
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/extension/programas-de-extension-universitaria.php">Programas de extensión</a></p>
                    </li>
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/extension/cursos">Cursos de extensión</a></p>
                    </li>
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/extension/becas/">Programa de becas</a>                    </p>
                    </li>
					<li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="https://www.derecho.uba.ar/publicaciones/pdf/programas-academicos-para-estudiantes-de-la-fd.pdf">Programas académicos</a>                    </p>
                    </li>
                </ul>
            </div>
            <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
                <h5 class="text-3 mb-3">Direcciones Útiles</h5>
                <ul class="list list-icons list-icons-lg">
                    <li class="mb-1">
                        <i title="Copiar Dirección" class="far fa-envelope text-color-primary"></i>
                        <p class="m-0"><a href="mailto:diralumnos@derecho.uba.ar">Estudiantes</a></p>
                    </li>
                    <li class="mb-1">
                        <i title="Copiar Dirección" class="far fa-envelope text-color-primary"></i>
                        <p class="m-0"><a href="mailto:areageneroest@derecho.uba.ar">Igualdad de género</a></p>
                    </li>
                    <li class="mb-1">
                        <i title="Copiar Dirección" class="far fa-envelope text-color-primary"></i>
                        <p class="m-0"><a href="mailto:posgrado@derecho.uba.ar">Posgrado</a></p>
                    </li>
                    <li class="mb-1">
                        <i title="Copiar Dirección" class="far fa-envelope text-color-primary"></i>
                        <p class="m-0"><a href="mailto:biblio@derecho.uba.ar">Biblioteca</a></p>
                    </li>
                </ul>
                <p class="mb-0"><a class="btn btn-xs btn-primary" href="index_contactenos.php">Directorio completo</a></p>
            </div>
            <div class="col-md-6 col-lg-4 mb-4 mb-md-0">
                <h5 class="text-3 mb-3 text-upper">Comunicación</h5>
                <p class="mb-1"><a href="/derechoaldia" class="text-4 link-hover-style-1">Derecho al Día</a></p>
              <p class="mb-1"><a href="/noticias" class="text-4 link-hover-style-1">Noticias</a></p>
                <p class="mb-1"><a href="/agenda" class="text-4 link-hover-style-1">Agenda</a></p>
                <p class="mb-1"><a href="/institucional/deinteres/convocatorias-vigentes.php" class="text-4 link-hover-style-1">Convocatorias</a></p>
                <p class="mb-1"><a href="https://docs.google.com/forms/d/e/1FAIpQLSdOC8BRpzHpWM6FE3LwhLRlD6PB5TEl1Bfv1KNg9syhZzteIA/viewform?usp=header" target="_blank" class="btn btn-xs btn-primary">Suscripción al news</a></p>
            </div>
        </div>
    </div>
    <div class="footer-copyright">
        <div class="container py-2">
            <div class="row py-4">
                <div class="col-lg-1 d-flex align-items-center justify-content-center justify-content-lg-start mb-2 mb-lg-0">
                    <a href="index.html" class="logo pe-0 pe-lg-3">
                        <img alt="Facultad de Derecho Logo" src="/img/logo-footer.png" class="opacity-5" height="32">
                    </a>
                </div>
                <div class="col-lg-7 d-flex align-items-center justify-content-center justify-content-lg-start mb-4 mb-lg-0">
                    <p>Facultad de Derecho | <a href="">Universidad de Buenos Aires</a> | Av. Figueroa Alcorta 2263, CABA | 5287-6700</p>
                </div>
                <div class="col-lg-4 d-flex align-items-center justify-content-center justify-content-lg-end">
                    <nav id="sub-menu">
                        <ul class="footer-social-icons social-icons m-0">
                            <li class="social-icons-facebook">
                                <a href="https://www.facebook.com/DerechoUBA" target="_blank" title="Facebook de la Facultad de Derecho">
                                    <i class="fab fa-facebook-f text-2"></i>
                                </a>
                            </li>
                            <li class="social-icons-twitter">
                                <a href="https://www.x.com/DerechoUBA" target="_blank" title="Cuenta de X de la Facultad de Derecho">
                                    <i class="fab fa-x-twitter text-2"></i>
                                </a>
                            </li>
                            <li class="social-icons-instagram">
                                <a href="https://www.instagram.com/fduba/" target="_blank" title="Instagram de la Facultad de Derecho">
                                    <i class="fab fa-instagram text-2"></i>
                                </a>
                            </li>
                            <li class="social-icons-youtube">
                                <a href="https://www.youtube.com/user/DerechoUBA" target="_blank" title="Canal de Youtube de la Facultad de Derecho">
                                    <i class="fab fa-youtube text-2"></i>
                                </a>
                            </li>
                            <li class="social-icons-pinterest">
                                <a href="http://www.pinterest.com/derechouba" target="_blank" title="Pinterest de la Facultad de Derecho">
                                    <i class="fab fa-pinterest text-2"></i>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-3764422-1', 'auto');
  ga('send', 'pageview');
</script> -->


<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-ZH1YV4P5ML"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-ZH1YV4P5ML');
</script>
    <!-- Vendor -->
<script src="/vendor/plugins/js/plugins.min.js"></script>

<!-- Link a Iconos -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Theme Base, Components and Settings -->
<script src="/js/theme.js"></script>

<!-- Circle Flip Slideshow Script -->
<script src="/vendor/circle-flip-slideshow/js/jquery.flipshow.min.js"></script>

<!-- Current Page Views -->
<script src="/js/views/view.home.js"></script>

<!-- Current Page Vendor and Views -->
<script src="/js/views/view.contact.js"></script>

<script src="/vendor/swiped-events/swiped-events.js"></script>

<!-- Theme Custom -->
<script src="/js/main.js"></script>
<script src="/js/custom.js"></script>

<!-- Theme Initialization Files -->
<script src="/js/theme.init.js"></script>

<script>
    (function($) {

'use strict';

/*
Thumb Gallery
*/
theme.fn.intObs( '.thumb-gallery-wrapper', function(){
    var $thumbGalleryDetail = $(this).find('.thumb-gallery-detail'),
        $thumbGalleryThumbs = $(this).find('.thumb-gallery-thumbs'),
        flag = false,
        duration = 300;

    $thumbGalleryDetail
        .owlCarousel({
            items: 1,
            margin: 10,
            nav: true,
            dots: false,
            loop: true,
            autoHeight: true,
            navText: [],
            rtl: ( $('html').attr('dir') == 'rtl' ) ? true : false
        })
        .on('changed.owl.carousel', function(e) {
            if (!flag) {
                flag = true;
                $thumbGalleryThumbs.trigger('to.owl.carousel', [e.item.index-1, duration, true]);

                $thumbGalleryThumbs.find('.owl-item').removeClass('selected');
                $thumbGalleryThumbs.find('.owl-item').eq( e.item.index ).addClass('selected');
                flag = false;
            }
        });

    
    $thumbGalleryThumbs
        .owlCarousel({
            margin: 15,
            items: $(this).data('thumbs-items') ? $(this).data('thumbs-items') : 4,
            nav: false,
            center: $(this).data('thumbs-center') ? true : false,
            dots: false,
            rtl: ( $('html').attr('dir') == 'rtl' ) ? true : false
        })
        .on('click', '.owl-item', function() {
            $thumbGalleryDetail.trigger('to.owl.carousel', [$(this).index(), duration, true]);
        })
        .on('changed.owl.carousel', function(e) {
            if (!flag) {
                flag = true;
                $thumbGalleryDetail.trigger('to.owl.carousel', [e.item.index, duration, true]);
                flag = false;
            }
        });

    $thumbGalleryThumbs.find('.owl-item').eq(0).addClass('selected');
}, {});

}).apply(this, [jQuery]);
</script>
</body>

</html>