<!DOCTYPE html>
<html lang="es">
<head>
    

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="author" content="kame-code.com">
<meta name="robots" content="index,follow">

<meta property="og:image" content="/img/logo/logo-media.png">
<meta property="og:image:type" content="image/png">
<meta property="og:image:width" content="363">
<meta property="og:image:height" content="363">

<!-- Mobile Specific Meta Tag-->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<!-- X TWITTER-->

<!-- Favicon and Apple Icons-->
<link rel="apple-touch-icon" sizes="57x57" href="/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon/favicon-16x16.png">
<link rel="manifest" href="/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<!-- Web Fonts  -->
<link id="googleFonts" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800%7CShadows+Into+Light&display=swap" rel="stylesheet" type="text/css">

<!-- Vendor CSS -->
<link rel="stylesheet" href="/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/vendor/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="/vendor/animate/animate.compat.css">
<link rel="stylesheet" href="/vendor/simple-line-icons/css/simple-line-icons.min.css">
<link rel="stylesheet" href="/vendor/owl.carousel/assets/owl.carousel.min.css">
<link rel="stylesheet" href="/vendor/owl.carousel/assets/owl.theme.default.min.css">
<link rel="stylesheet" href="/vendor/magnific-popup/magnific-popup.min.css">

<!-- Theme CSS -->
<link rel="stylesheet" href="/css/theme.css">
<link rel="stylesheet" href="/css/theme-elements.css">
<link rel="stylesheet" href="/css/theme-blog.css">
<link rel="stylesheet" href="/css/theme-shop.css">

<!-- Skin CSS -->
<link id="skinCSS" rel="stylesheet" href="/css/skins/derecho.css">

<!-- Theme Custom CSS -->
<link rel="stylesheet" href="/css/custom.css?1682693634">

<!-- Head Libs -->
<script src="/vendor/modernizr/modernizr.min.js"></script>

<base href="https://www.derecho.uba.ar" />
    <meta name="description" content="Facultad de Derecho de la Universidad de Buenos Aires">
    <title>Proyectos UBACyT - Investigaci&oacute;n | Facultad de Derecho - Universidad de Buenos Aires</title>
</head>
<body class="cbp-spmenu-push">
    <div class="container">
        <nav id="menu-offcanvas" class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">
            <h3>Secretar&iacute;a de Investigaci&oacute;n<a class="glyphicon glyphicon-remove" id="hideLeftPush"></a></h3>
            <ul class="nav nav-list flex-column mb-5"><li class="nav-item"><a href="investigacion/inv_institutos.php" class="nav-link">Institutos de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_proyectos_vigentes.php" class="nav-link">Proyectos de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_becarios.php" class="nav-link">Becarios/as de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_programas_estudiantes.php" class="nav-link">Programas para estudiantes</a></li>
<li class="nav-item"><a href="investigacion/inv_programas_docentes_investigadores.php" class="nav-link">Programas para docentes-investigadores/as</a></li>
<li class="nav-item"><a href="investigacion/investigacion_investigadores_visitantes.php" class="nav-link">Investigadores/as visitantes</a></li>
<li class="nav-item"><a href="investigacion/agenda/" class="nav-link">Agenda</a></li>
<li class="nav-item"><a href="investigacion/noticias/" class="nav-link">Noticias</a></li>
</ul><h5 class=" text-2 pt-4">Contacto</h5>
    <ul class="list list-icons list-icons-style-2 mt-2">
        <li><i class="fas fa-map-marker-alt top-6"></i>Primer Piso</li>
        <li><i class="fas fa-clock top-6"></i>Lunes a viernes 10 a 20 hs (atención telefónica) - Lunes a viernes 10 a 19 hs (atención presencial)</li>
        <li><i class="fas fa-phone top-6"></i> (5411) 5287-7096</li>
        <li><i class="fas fa-envelope top-6"></i> <a href="mailto:investigacion@derecho.uba.ar">investigacion@derecho.uba.ar</a></li>
    </ul>
<h5 class="text-2 pt-4">Redes</h5>
    <ul class="social-icons">
        <li class="social-icons-twitter"><a href="http://twitter.com/SI_DerechoUBA  " target="_blank"><i class="fab fa-twitter"></i></a></li>
        <li class="social-icons-instagram"><a href="https://www.instagram.com/si_derechouba/  " target="_blank"><i class="fab fa-instagram"></i></a></li>
        <li class="social-icons-youtube"><a href="https://www.youtube.com/channel/UCFz7MFrOGcFxkQbrItItzTw  " target="_blank"><i class="fab fa-youtube"></i></a></li>
    </ul>        </nav>
        
                <header id="header">
    <div class="header-top">
        <div class="row">

		
            <div class="col-lg-6 col-md-4 col-sm-4">
		<!--	<img src="/imagenes/logo-uba-200.png" alt="200 años UBA" style="width: 64px; margin-left:3px;">-->
                <a href="/" title="Facultad de Derecho - UBA"><img src="imagenes/banner-negro.png" class="banner" style="margin-left:3px;"></a>
                <button type="button" id="showLeftPush" class="navbar-toggle navbar-toggle-aside-menu">
                    <span class="fa fa-outdent"></span>
                </button>
                <button type="button" class="navbar-toggle open-collapse" data-toggle="collapse" data-target=".menu-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>

            <nav class="col-lg-6 col-md-8 col-sm-8 perfiles">
                <ul class="list-inline float-right">
                    <li class="list-inline-item">
                        <a title="Sector Ingresantes - Facultad de Derecho" href="ingresantes">Ingresantes</a>
                    </li>
                    <li class="list-inline-item">
                        <a title="Sector Alumnos - Facultad de Derecho" href="/estudiantes/">Estudiantes</a>
                    </li>
                    <li class="list-inline-item">
                        <a title="Sector Docentes - Facultad de Derecho" href="docentes">Docentes</a>
                    </li>
                    <li class="list-inline-item">
                        <a title="Sector Graduados - Facultad de Derecho" href="graduados">Graduadas/os</a>&nbsp;&nbsp;
                    </li>
                </ul>
            </nav>
            <!-- search -->

            <form class="search hidden-xs" action="/index_resbus.php" id="cse-search-box" accept-charset="utf-8">
                <input type="hidden" name="cx" value="007910097264156725590:4u2nbtj2ado">
                <input type="hidden" name="cof" value="FORID:11">
                <input type="hidden" name="ie" value="utf-8">
                <input type="text" class="form-control boton-goo1" name="q" placeholder="Buscar...">
                <span class="fa fa-search"></span>
            </form>
            <!-- /search -->
            
            <div class="navbar-collapse menu-collapse collapse">
                <ul class="nav navbar-nav">
                    <li><a href="/institucional">Institucional</a></li>
                    <li><a href="/academica">Académica</a></li>
                    <li><a href="/investigacion">Investigación</a></li>
                    <li><a href="/extension">Extensión</a></li>
                    <li><a href="/internacionales">Internacionales</a></li>
                    <li><a href="/publicaciones">Publicaciones</a></li>
                    <li><a href="/biblioteca">Biblioteca</a></li>
                    <li><a href="/academica/posgrados">Posgrado</a></li>
                </ul>
                <div class="visible-xs">        
                    <form class="search" action="/index_resbus.php" id="cse-search-box" accept-charset="utf-8">
                        <input type="hidden" name="cx" value="007910097264156725590:4u2nbtj2ado">
                        <input type="hidden" name="cof" value="FORID:11">
                        <input type="hidden" name="ie" value="utf-8">
                        <input type="text" class="form-control boton-goo1" name="q" placeholder="Buscar...">
                        <span class="fa fa-search"></span>
                    </form>
                    <!--
                    <form action="/index_resbus.php" id="cse-search-box" accept-charset="utf-8">
                        <input type="hidden" name="cx" value="007910097264156725590:4u2nbtj2ado">
                        <input type="hidden" name="cof" value="FORID:11">
                        <input type="hidden" name="ie" value="utf-8">
                        <div class="input-group input-group-sm">
                            <input type="text" class="form-control" placeholder="Buscar" name="q">
                            <div class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <span class="glyphicon glyphicon-search"></span>
                                </button>
                            </div>
                        </div>
                    </form>
                    -->
                </div>
            </div>

        </div>
    </div>
    <div class="menu">
        <div class="row">
            <nav class="col-md-12">
                <ul class="list-inline d-flex justify-content-around">
                    <li class="list-inline-item text-center">
                        <a title="Facultad de Derecho" href="institucional">Institucional</a>
                    </li>
                    <li class="list-inline-item text-center">
                        <a title="Carreras, posgrados, formación docente" href="academica">Académica</a>
                    </li>
                    <li class="list-inline-item text-center">
                        <a title="Institutos de investigación, proyectos de investigación" href="investigacion">Investigación</a>
                    </li>
                    <li class="list-inline-item text-center">
                        <a title="Cursos, becas, deportes" href="extension">Extensión</a>
                    </li>
                    <li class="list-inline-item text-center">
                        <a title="Cooperación internacional de la Facultad de Derecho" href="internacionales">Internacionales</a>
                    </li>
                    <li class="list-inline-item text-center">
                        <a title="Publicaciones periódicas, libros, revistas" href="publicaciones">Publicaciones</a>
                    </li>
                    <li class="list-inline-item text-center">
                        <a title="Préstamos, libros electrónicos, catálogos" href="biblioteca">Biblioteca</a>
                    </li>
                    <li class="list-inline-item text-center">
                        <a title="Doctorado, posdoctorado, maestrías" href="academica/posgrados">Posgrado</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</header>                
        <nav class="MenuSector">
            <div class="pull-left sector">
                <a class="location" href="/investigacion/">Investigaci&oacute;n</a>
            </div>
            <ol class="breadcrumb pull-right hidden-xs">
                <li><a href="index.php">Inicio</a></li><li><a href="/investigacion/">Investigacion</a></li><li><a href="investigacion/inv_proyectos_vigentes.php">Proyectos de Investigaci&oacute;n vigentes</a></li><li><a href="investigacion/inv_prog_ubacyt.php">Proyectos UBACyT 2010-2012</a></li><li><a href="investigacion/en-inv_proyectos_vigentes_ubacyt_2013_etcheverry-junqueira.php" title="information for foreigners">English version</a></li>
            </ol>
            <div class="clearfix"></div>
        </nav>
        
        <section class="row">
            <div class="col-lg-3 col-md-3 col-sm-4 menu_izq hidden-xs">
                <p>Secretar&iacute;a de Investigaci&oacute;n</p>
                <nav>
                    <ul class="nav nav-list flex-column mb-5"><li class="nav-item"><a href="investigacion/inv_institutos.php" class="nav-link">Institutos de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_proyectos_vigentes.php" class="nav-link">Proyectos de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_becarios.php" class="nav-link">Becarios/as de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_programas_estudiantes.php" class="nav-link">Programas para estudiantes</a></li>
<li class="nav-item"><a href="investigacion/inv_programas_docentes_investigadores.php" class="nav-link">Programas para docentes-investigadores/as</a></li>
<li class="nav-item"><a href="investigacion/investigacion_investigadores_visitantes.php" class="nav-link">Investigadores/as visitantes</a></li>
<li class="nav-item"><a href="investigacion/agenda/" class="nav-link">Agenda</a></li>
<li class="nav-item"><a href="investigacion/noticias/" class="nav-link">Noticias</a></li>
</ul><h5 class=" text-2 pt-4">Contacto</h5>
    <ul class="list list-icons list-icons-style-2 mt-2">
        <li><i class="fas fa-map-marker-alt top-6"></i>Primer Piso</li>
        <li><i class="fas fa-clock top-6"></i>Lunes a viernes 10 a 20 hs (atención telefónica) - Lunes a viernes 10 a 19 hs (atención presencial)</li>
        <li><i class="fas fa-phone top-6"></i> (5411) 5287-7096</li>
        <li><i class="fas fa-envelope top-6"></i> <a href="mailto:investigacion@derecho.uba.ar">investigacion@derecho.uba.ar</a></li>
    </ul>
<h5 class="text-2 pt-4">Redes</h5>
    <ul class="social-icons">
        <li class="social-icons-twitter"><a href="http://twitter.com/SI_DerechoUBA  " target="_blank"><i class="fab fa-twitter"></i></a></li>
        <li class="social-icons-instagram"><a href="https://www.instagram.com/si_derechouba/  " target="_blank"><i class="fab fa-instagram"></i></a></li>
        <li class="social-icons-youtube"><a href="https://www.youtube.com/channel/UCFz7MFrOGcFxkQbrItItzTw  " target="_blank"><i class="fab fa-youtube"></i></a></li>
    </ul>                </nav>
            </div>
    
            <div class="contenido_pagina-col2 col-lg-9 col-md-9 col-sm-8">
                
   <h1>Proyectos UBACyT</h1>
   <h3>Fecha de inicio </h3>
   <p class="tabulado">01/07/2013</p>
   <h3>Fecha de finalizaci&oacute;n </h3>
   <p class="tabulado">30/06/2016</p>
   <h3>C&oacute;digo </h3>
   <p class="tabulado">20020120100263BA<br />
   </p>
   <h3>Tipo de proyecto </h3>
   <p class="tabulado">Grupo consolidado</p>
   <h3>T&iacute;tulo</h3>
   <p class="tabulado">    Investigaci&oacute;n para la creaci&oacute;n de principios y normas tendientes a regular las Empresas B (B corporations) en la Rep&uacute;blica Argentina.</p>
   <h3>Director</h3>
   <p class="tabulado">Etcheverry, Ra&uacute;l An&iacute;bal</p>
   <h3>Codirectora</h3>
   <p class="tabulado">Junqueira, Susana Graciela</p>
   <h3>Contacto</h3>
   <p class="tabulado"><a href="mailto:rauletc@estudioegchv.com.ar" target="_blank">rauletc@estudioegchv.com.ar</a><a href="mailto:lermanmarcelo@hotmail.com" target="_blank"></a></p>
   <p>&nbsp;</p>
   <div class="table-responsive"><table class="table table-striped table-bordered"><thead><tr class="celeste">
         <th colspan="2" align="center"><strong>INTEGRANTES</strong></th>
        </tr></thead><tbody><tr>
         <td align="center" valign="middle" width="16%"><strong>N&deg;</strong></td>
         <td align="center" valign="middle"><strong>Nombre y apellido</strong></td>
        </tr><tr>
         <td align="center" valign="middle">1</td>
         <td align="center" valign="middle">Ra&uacute;l Bernardo Etcheverry           <br /></td>
        </tr><tr>
         <td align="center" valign="middle">2</td>
         <td align="center" valign="middle">Mar&iacute;a Marta Oriozabala<br /></td>
       </tr><tr>
         <td align="center" valign="middle">3</td>
         <td align="center" valign="middle">Alejandra Noem&iacute; Tevez           <br /></td>
       </tr><tr>
         <td align="center" valign="middle">4</td>
         <td align="center" valign="middle">Lidia Mar&iacute;a Rosa Garrido Cordobera</td>
       </tr><tr>
         <td align="center" valign="middle">5</td>
         <td align="center" valign="middle">Esther Haydee Silvia Ferrer</td>
       </tr></tbod></table></div>
   <p>&nbsp;</p>
   <p><strong>PALABRAS CLAVE</strong></p>
   <p class="tabulado">Empresas B<br />
     Acci&oacute;n social<br />
     Protecci&oacute;n ambiental<br />
   </p>
   <p><br />
    <strong>RESUMEN</strong></p>
   <p class="tabulado">En la Rep&uacute;blica Argentina y buena parte de los pa&iacute;ses Latinoamericanos, los principales entes organizados para actuar en el mercado son: las asociaciones, las fundaciones, las cooperativas y las sociedades tanto civiles o comerciales. Estos entes organizados tienen una ?tipicidad? cerrada que no les permite compartir o mezclar sus fines. Se trata de empresas que pese a que su motivaci&oacute;n excede el af&aacute;n de lucro, necesitan dinero para seguir promoviendo su principal objetivo de resolver problemas ambientales o sociales. En varios pa&iacute;ses del mundo se est&aacute; estudiando darle un marco legal a una nueva estructura de organizaci&oacute;n, en la cual se permita mezclar el objeto y definir claramente un nuevo objeto social dividi&eacute;ndose el mismo, parte en actividad econ&oacute;mica con beneficios repartibles y otra parte con beneficios canalizados hacia fines sociales. Partiremos de la hip&oacute;tesis de que las empresas B o &quot;B corporations&quot; no admiten su regulaci&oacute;n en el derecho argentino sin violaci&oacute;n de normas imperativas. Sin embargo, su estructura importa un instrumento jur&iacute;dico &uacute;til para resolver las necesidades de las empresas y de la sociedad y cumplir&aacute;n, en caso de ser recibidas, una importante funci&oacute;n social. A trav&eacute;s de una metodolog&iacute;a te&oacute;rica-emp&iacute;rica con enfoque sist&eacute;mico, intentaremos establecer y determinar: 1.- La problem&aacute;tica planteada por las empresas comunes, que buscan fines lucrativos. 2.- La problem&aacute;tica planteada relativa a la finalidad de la empresa como motor de la sociedad. 3.- La existencia o no de crisis de la finalidad de la empresa regulada en la Ley de Sociedades y en Proyecto de unificaci&oacute;n del C&oacute;digo Civil y Comercial de 2012. 4.- En el examen de los diferentes casos, a partir de la teor&iacute;a de la responsabilidad social empresaria, que es siempre voluntaria, se buscar&iacute;a c&oacute;mo podr&iacute;a devenir en obligatoria. 5.- La soluci&oacute;n estatutaria; su posible insuficiencia. 6.- La correcta soluci&oacute;n para esta nueva clase de empresas. Los resultados de la investigaci&oacute;n ser&aacute;n transferidos al Poder Legislativo Nacional y a otras instituciones del Estado. Asimismo ser&aacute;n transferidos a la Maestr&iacute;a de Derecho Comercial y de los Negocios de la Facultad de Derecho de la Universidad de Buenos Aires que dirige el Prof. Dr. Ra&uacute;l An&iacute;bal Etcheverry, director del presente Proyecto de Investigaci&oacute;n, y constituir&aacute; una actividad del Centro de Investigaci&oacute;n Pacem, perteneciente tambi&eacute;n a la Facultad de Derecho de la Universidad de Buenos Aires, y que tambi&eacute;n dirige el director del proyecto.</p>

   
   
  
            </div>
        </section>
    </div>
    
    
    <footer id="footer">
        <div class="container footer">
            <div class="row">
                <!-- Footer Content -->
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="de-interes">
                      <h3 class="h6 subrayado text-uppercase">Accesos directos</h3>
                        <ul class="list-unstyled interes" style="margin-bottom:0">
                            <li><i class="fa fa-circle"></i><a title="Consejo Directivo de la Facultad de Derecho" href="institucional/consejo-directivo/">Consejo Directivo</a></li>
                            <li><i class="fa fa-circle"></i><a href="investigacion/inv_proyectos_vigentes.php">Proyectos de investigaci&oacute;n</a></li>
                            <li><i class="fa fa-circle"></i><a title="Programas de intercambio" href="internacionales/programas-de-intercambio-estudiantil.php">Programas de intercambio estudiantil</a></li>
                            <li><i class="fa fa-circle"></i><a title="Carrera y Formaci&oacute;n Docente" href="academica/carrdocente/">Carrera Docente</a></li>
                            <li><i class="fa fa-circle"></i><a href="internacionales/ciclo-de-cursos-on-line/">Ciclo de cursos online (CCO)</a></li>
                            <li><i class="fa fa-circle"></i><a title="Observatorios y Centros de Estudios de la Facultad de Derecho" href="institucional/observatorios-y-centros-de-estudios.php">Observatorios y Centros de Estudios</a></li>
                            <li><i class="fa fa-circle"></i><a href="extension/programas-de-extension-universitaria.php">Programas de extensión</a></li>
                            <li><i class="fa fa-circle"></i><a title="Ciclo de Grandes Conciertos" href="extension/conciertos.php">Ciclo de Grandes Conciertos</a></li                          <li><i class="fa fa-circle"></i><a title="Cursos de extensión" href="extension/cursos">Cursos de extensión</a></li>
                            <li><i class="fa fa-circle"></i><a title="Programa de becas" href="extension/becas/">Programa de becas</a></li>
                            <li><i class="fa fa-circle"></i><a title="Informes" href="institucional/deinteres/informes-de-gestion.php">Informes de gestión</a></li>
                        </ul>
                    </div>
                </div>
                <!-- End Footer Content -->

                <!-- Footer Content -->
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="comunicacion">
                        <h3 class="h6 subrayado text-uppercase">Comunicación</h3>
                        <ul class="list-unstyled mb-4">
                            <li>
                                <h4 class="h6 mb-0"><a href="derechoaldia">Derecho al Día</a></h4>
                            </li>
                            <li>
                                <h4 class="h6 mb-0"><a href="noticias">Noticias</a></h4>
                            </li>
                            <li>
                                <h4 class="h6 mb-0"><a href="institucional/derechoenradiouba/">Derecho en Radio UBA</a></h4>
                            </li>
                        </ul>

                       <a href="https://www.facebook.com/DerechoUBA" target="_blank"><span class="fa fa-facebook color-facebook social"></span></a>
                       <a href="https://www.x.com/DerechoUBA" target="_blank"><span class="fa fa-twitter color-twitter social"></span></a>
                       <a href="https://www.instagram.com/fduba/" target="_blank"><span class="fa fa-instagram color-instagram social"></span></a>
                       <a href="https://www.youtube.com/user/DerechoUBA" target="_blank"><span class="fa fa-youtube-play color-youtube social"></span></a>
					   <a href="http://www.pinterest.com/derechouba" target="_blank"><span class="fa fa-pinterest color-youtube social"></span></a>
                    </div>
                </div>
                <!-- End Footer Content -->

                <!-- Footer Content -->
                <div class="col-lg-4 col-md-4 col-sm-12">
                    <div class="direcciones-utiles">
                        <h3 class="h6 subrayado text-uppercase">Direcciones útiles</h3>
                        <ul class="list-unstyled">
                            <li class="mb-1"><strong>Estudiantes |</strong> <a href="mailto:diralumnos@derecho.uba.ar" title="Mail Direccion de Alumnos">diralumnos@derecho.uba.ar</a></li>
                            <li class="mb-1"><strong>Igualdad de g&eacute;nero</strong> | <a href="mailto:areageneroest@derecho.uba.ar">areageneroest@derecho.uba.ar</a></li>
                            <li class="mb-1"><strong>Posgrado |</strong> <a href="mailto:posgrado@derecho.uba.ar">posgrado@derecho.uba.ar</a></li>
                            <li class="mb-1"><strong>Extensión |</strong> <a href="mailto:eextensionuniversitaria@derecho.uba.ar">extensionuniversitaria@derecho.uba.ar</a></li>
                            <li class="mb-1"><strong>Investigación |</strong> <a href="mailto:investigacion@derecho.uba.ar">investigacion@derecho.uba.ar</a></li>
                            <li class="mb-1"><strong>Internacionales |</strong> <a href="mailto:internacionales@derecho.uba.ar">internacionales@derecho.uba.ar</a></li>
                            <li><strong>Institucionales |</strong> <a href="mailto:institucionales@derecho.uba.ar">institucionales@derecho.uba.ar</a></li>  
                            <li class="mb-1"><strong>Publicaciones |</strong>&nbsp;<a href="mailto:dpublica@derecho.uba.ar">dpublica@derecho.uba.ar</a></li>
                            <li class="mb-1"><strong>Biblioteca |</strong> <a href="mailto:biblio@derecho.uba.ar">biblio@derecho.uba.ar</a></li>
                        </ul>
                        <p><a class="btn bg-1 btn-sm" href="index_contactenos.php">Ver directorio completo</a></p>
                    </div>
                </div>
                <!-- End Footer Content -->
            </div>
        </div>
        <div class="footer-info">
            <div class="container">
              <small class="">Facultad de Derecho | <a target="_blank" href="http://www.uba.ar" class="color-1">Universidad de Buenos Aires</a></small> | <small class="">Av. Figueroa Alcorta 2263, CABA | 5287-6700</small>
            </div>
        </div>
    </footer>

    <script>
        /*
        $('a').each(function () {
            var href = $(this).attr('href'), hashes, hash = '';
            if (href) {
                var queryString = (href.indexOf('?') !== -1) ? '&new' : '?new';
                if (hashes = href.match(/#[a-z0-9]+/gi)) {
                    hash = hashes[0];
                    href = href.replace(hash, '');
                }
                $(this).attr('href', href + queryString + hash);
            }
        });
        
        $('.menu_izq nav').affix({
          offset: {
            top: 210,
            bottom: function () {
                return (this.bottom = $('#footer').outerHeight(true))
            }
          }
        });
        */
    </script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-3764422-1', 'auto');
  ga('send', 'pageview');

</script></body>
</html>
