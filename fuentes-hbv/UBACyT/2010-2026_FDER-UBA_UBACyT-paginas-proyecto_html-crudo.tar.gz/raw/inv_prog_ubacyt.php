
<!DOCTYPE html>
<html lang="es">
<head>
    
    

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="author" content="kame-code.com">
<meta name="robots" content="index,follow">

<meta property="og:image" content="/img/logo/logo-media.png">
<meta property="og:image:type" content="image/png">
<meta property="og:image:width" content="363">
<meta property="og:image:height" content="363">

<!-- Mobile Specific Meta Tag-->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<!-- X TWITTER-->

<!-- Favicon and Apple Icons-->
<link rel="apple-touch-icon" sizes="57x57" href="/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon/favicon-16x16.png">
<link rel="manifest" href="/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<!-- Web Fonts  -->
<link id="googleFonts" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800%7CShadows+Into+Light&display=swap" rel="stylesheet" type="text/css">

<!-- Vendor CSS -->
<link rel="stylesheet" href="/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/vendor/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="/vendor/animate/animate.compat.css">
<link rel="stylesheet" href="/vendor/simple-line-icons/css/simple-line-icons.min.css">
<link rel="stylesheet" href="/vendor/owl.carousel/assets/owl.carousel.min.css">
<link rel="stylesheet" href="/vendor/owl.carousel/assets/owl.theme.default.min.css">
<link rel="stylesheet" href="/vendor/magnific-popup/magnific-popup.min.css">

<!-- Theme CSS -->
<link rel="stylesheet" href="/css/theme.css">
<link rel="stylesheet" href="/css/theme-elements.css">
<link rel="stylesheet" href="/css/theme-blog.css">
<link rel="stylesheet" href="/css/theme-shop.css">

<!-- Skin CSS -->
<link id="skinCSS" rel="stylesheet" href="/css/skins/derecho.css">

<!-- Theme Custom CSS -->
<link rel="stylesheet" href="/css/custom.css?1682693634">

<!-- Head Libs -->
<script src="/vendor/modernizr/modernizr.min.js"></script>

<base href="https://www.derecho.uba.ar" />
    <meta name="description" content="Facultad de Derecho de la Universidad de Buenos Aires">
    <title>Programaci&oacute;n UBACyT - Investigaci&oacute;n | Facultad de Derecho - Universidad de Buenos Aires</title>

</head>
<body class="cbp-spmenu-push" data-plugin-page-transition data-plugin-scroll-spy data-plugin-options="{'target': '#sidebar'}">
    <div class="body">
        <header id="header" class="header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': false, 'stickyChangeLogo': true, 'stickyStartAt': 30, 'stickyHeaderContainerHeight': 52}">
    <div class="header-body border-top-0">
        <div class="header-top">
            <div class="container">
                <div class="header-row py-md-2">
                    <div id="header-top-column" class="header-column justify-content-start">
                        <div class="header-row">
                            <nav id="header-nav-top" class="header-nav-top">
                                <ul class="nav nav-pills text-3">
                                    <li class="nav-item">
                                        <a class="nav-link ps-0 text-secondary" title="Información para ingresantes de la Facultad de Derecho" href="/ingresantes">
                                            Ingresantes
                                        </a>
                                    </li>
                                    <li class="nav-item nav-item-left-border">
                                        <a class="nav-link pe-0 text-secondary" title="Estudiantes de la Facultad de Derecho" href="/estudiantes">
                                            Estudiantes
                                        </a>
                                    </li>
                                    <li class="nav-item nav-item-left-border">
                                        <a class="nav-link ps-0 text-secondary" title="Docentes de la Facultad de Derecho" href="/docentes">
                                            Docentes
                                        </a>
                                    </li>
                                    <li class="nav-item nav-item-left-border">
                                        <a class="nav-link ps-0 text-secondary" title="Graduados de la Facultad de Derecho" href="/graduados">
                                            <span class="d-none d-sm-inline">Graduadas/os</span>
                                            <span class="d-inline d-sm-none">Graduadas</span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="header-column justify-content-end">
                        <div class="header-row">
                            <nav class="header-nav-top">
                                <ul class="nav nav-pills text-uppercase text-2">
                                  <li class="nav-item nav-item-anim-icon d-none d-md-block"><a class="nav-link pe-0" href="https://3w.derecho.uba.ar/" target="_blank">
                                      <i class="fas fa-angle-right"></i>
                                      SIU-Guaraní
                                  </a>                                  </li>
                                </ul>
                            </nav>
                            <div class="header-nav-features d-none d-md-block">
                                <div class="header-nav-features-search-reveal-container">
                                    <div class="header-nav-feature header-nav-features-search header-nav-features-search-reveal d-inline-flex">
                                        <a href="#" class="header-nav-features-search-show-icon d-inline-flex text-decoration-none"><i class="fas fa-search header-nav-top-icon"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="header-row">
                    <div class="header-nav-features header-nav-features-no-border p-static z-index-2">
                        <div class="header-nav-feature header-nav-features-search header-nav-features-search-reveal header-nav-features-search-reveal-big-search px-3">
                            <form role="search" class="d-flex w-100 h-100" action="/index_resbus.php" method="get" accept-charset="utf-8">
                                <div class="big-search-header input-group">
                                    <input class="form-control text-1" name="q" type="search" value="" placeholder="Buscar...">
                                    <input type="hidden" name="cx" value="007910097264156725590:4u2nbtj2ado">
                                    <input type="hidden" name="cof" value="FORID:11">
                                    <input type="hidden" name="ie" value="utf-8">
                                    <a href="#" class="header-nav-features-search-hide-icon"><i class="fas fa-times header-nav-top-icon"></i></a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-container container d-none d-md-flex">
            
            <div class="header-row">
                <div class="header-column justify-content-start justify-content-md-center order-1 order-md-2">
                    <div class="header-row">
                        <div class="header-logo justify-content-center">
                            <a href="/" title="Facultad de Derecho de la Universidad de Buenos Aires">
                                <img alt="Facultad de Derecho" width="371" height="52" data-sticky-width="307" data-sticky-height="43" src="/img/logo-header.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-nav-bar header-nav-bar-top-border">
            <div class="header-container container">
                <div class="header-row">
                    <div class="header-column justify-content-center d-flex d-md-none">
                        <a href="/" title="Facultad de Derecho de la Universidad de Buenos Aires">
                            <img alt="Facultad de Derecho" width="220" src="/img/logo-header.png">
                        </a>
                    </div>
                    <div class="header-column">
                        <div class="header-row justify-content-end">
                            <div class="header-nav p-0">
                                <div class="header-nav header-nav-links justify-content-lg-center">
                                    <div class="header-nav-main header-nav-main-square header-nav-main-dropdown-no-borders header-nav-main-dropdown-arrow header-nav-main-dropdown-center header-nav-main-dropdown-center-bottom header-nav-main-effect-3 header-nav-main-sub-effect-1">
                                        <nav class="collapse">
                                            <ul class="nav nav-pills" id="mainNav">
                                                <li><a href="/institucional">Institucional</a></li>
                                                <li><a href="/academica">Académica</a></li>
                                                <li><a href="/investigacion">Investigación</a></li>
                                                <li><a href="/extension">Extensión</a></li>
                                                <li><a href="/internacionales">Internacionales</a></li>
                                                <li><a href="/publicaciones">Publicaciones</a></li>
                                                <li><a href="/biblioteca">Biblioteca</a></li>
                                                <li><a href="/academica/posgrados">Posgrado</a></li>
                                            </ul>
                                            <div class="d-lg-none">        
                                                <form role="search" action="/index_resbus.php" id="cse-search-box" accept-charset="utf-8">
                                                    <div class="simple-search input-group">
                                                        <input class="form-control text-1" id="headerSearch" name="q" type="search" value="" placeholder="Buscar...">
                                                        <input type="hidden" name="cx" value="007910097264156725590:4u2nbtj2ado">
                                                        <input type="hidden" name="cof" value="FORID:11">
                                                        <input type="hidden" name="ie" value="utf-8">
                                                        <button class="btn" type="submit"> <i class="fas fa-search header-nav-top-icon text-color-dark"></i> </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </nav>
                                    </div>
                                    <button class="btn header-btn-collapse-nav" data-bs-toggle="collapse" data-bs-target=".header-nav-main nav">
                                        <i class="fas fa-bars"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="header-nav-features header-nav-features-no-border header-nav-features-lg-show-border order-1 order-lg-2">
                        <div class="header-nav-feature header-nav-features-search d-inline-flex">
                            <a href="#" class="header-nav-features-toggle text-decoration-none show-menu d-show d-md-none">
                                <span class="fa fa-outdent"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
        <main role="main" class="main">
            <nav id="menu-offcanvas" class="cbp-spmenu">
                <!-- Contenido Din�mico - No remover -->
            </nav>

            <section class="page-header page-header-modern bg-color-light-scale-1 page-header-sm">
                <div class="container">
                    <div class="row">
                        <div class="col-12 align-self-center">
                            <ul class="breadcrumb d-block">
                                
                <li><a href="index.php">Inicio</a></li><li><a href="/investigacion/">Investigacion</a></li><li><a href="investigacion/inv_proyectos_vigentes.php">Proyectos de Investigaci&oacute;n vigentes</a></li><li><a href="investigacion/inv_prog_ubacyt.php">Proyectos UBACyT 2020-2022</a></li><li><a href="investigacion/en-inv_prog_ubacyt.php" title="information for foreigners">English version</a></li>
            
                            </ul>
                        </div>
                    </div>
                </div>
            </section>

            <div class="container my-3">
                <div class="row py-3">
                    <div class="col-lg-3 position-relative d-none d-lg-flex">
                        <nav class="sidebar" id="sidebar" data-plugin-sticky data-plugin-options="{'minWidth': 991, 'containerSelector': '.container', 'padding': {'top': 130}}">
                            <h5 class="font-weight-semi-bold">
                                Investigaci&oacute;n
                                <span class="fa fa-2x fa-times d-none hide-menu"></span>
                            </h5>
                            
                            
                    <ul class="nav nav-list flex-column mb-5"><li class="nav-item"><a href="investigacion/inv_institutos.php" class="nav-link">Institutos de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_proyectos_vigentes.php" class="nav-link">Proyectos de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_becarios.php" class="nav-link">Becarios/as de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_programas_estudiantes.php" class="nav-link">Programas para estudiantes</a></li>
<li class="nav-item"><a href="investigacion/inv_programas_docentes_investigadores.php" class="nav-link">Programas para docentes-investigadores/as</a></li>
<li class="nav-item"><a href="investigacion/investigacion_investigadores_visitantes.php" class="nav-link">Investigadores/as visitantes</a></li>
<li class="nav-item"><a href="investigacion/agenda/" class="nav-link">Agenda</a></li>
<li class="nav-item"><a href="investigacion/noticias/" class="nav-link">Noticias</a></li>
</ul><h5 class=" text-2 pt-4">Contacto</h5>
    <ul class="list list-icons list-icons-style-2 mt-2">
        <li><i class="fas fa-map-marker-alt top-6"></i>Primer Piso</li>
        <li><i class="fas fa-clock top-6"></i>Lunes a viernes 10 a 20 hs (atención telefónica) - Lunes a viernes 10 a 19 hs (atención presencial)</li>
        <li><i class="fas fa-phone top-6"></i> (5411) 5287-7096</li>
        <li><i class="fas fa-envelope top-6"></i> <a href="mailto:investigacion@derecho.uba.ar">investigacion@derecho.uba.ar</a></li>
    </ul>
<h5 class="text-2 pt-4">Redes</h5>
    <ul class="social-icons">
        <li class="social-icons-twitter"><a href="http://twitter.com/SI_DerechoUBA  " target="_blank"><i class="fab fa-twitter"></i></a></li>
        <li class="social-icons-instagram"><a href="https://www.instagram.com/si_derechouba/  " target="_blank"><i class="fab fa-instagram"></i></a></li>
        <li class="social-icons-youtube"><a href="https://www.youtube.com/channel/UCFz7MFrOGcFxkQbrItItzTw  " target="_blank"><i class="fab fa-youtube"></i></a></li>
    </ul>                
                            
                        </nav>
                    </div>
                    <div class="col-lg-9 contenido_pagina-col2">
                        

                <h1>Programaci&oacute;n UBACYT </h1>
<p>Los proyectos UBACyT son financiados y acreditados por la Universidad de Buenos Aires. Anualmente se realiza una convocatoria en la que los/las docentes de las distintas Facultades pueden presentar propuestas de investigaci&oacute;n. Esas propuestas son evaluadas por Comisiones T&eacute;cnicas Asesoras y finalmente el Consejo Superior de la Universidad selecciona los proyectos que deben acreditarse. En esta p&aacute;gina encontrar&aacute; la informaci&oacute;n acerca de los proyectos radicados en la Facultad de Derecho.</p>
                <ul>
                    <li><a href="investigacion/reglamento-subsidiosa-la-investigacion-cient&iacute;fica-y-tecnologica.pdf" target="_blank">R&eacute;gimen de Subsidios a la Investigaci&oacute;n Cient&iacute;fica y Tecnol&oacute;gica</a> (Res. CS. 1793/2010) <span class="filetype"><span class="label pdf">PDF</span></span></li>
                    <li>Para novedades, formularios actualizados y m&aacute;s informaci&oacute;n acerca de los proyectos UBACyT en general, dir&iacute;jase al <a href="https://cyt.rec.uba.ar/" target="_blank">sitio web de la Secretar&iacute;a de Ciencia y T&eacute;cnica del Rectorado de la UBA</a></li>
                    <li><a href="investigacion/inv_becarios_ubacyt.php">M&aacute;s informaci&oacute;n sobre los becarios UBACyT</a></li>
                </ul>
                <h3>Proyectos vigentes</h3>
                <p><strong>MODALIDAD I</strong></p>
                <table class="table table-bordered table-striped">
                  <thead>
                    <tr class="celeste">
                      <th width="16%">C&oacute;digo</th>
                      <th width="21%">Director/a - Codirector/a </th>
                      <th width="43%">T&iacute;tulo</th>
                      <th width="9%">Inicio</th>
                      <th width="11%">Finalizaci&oacute;n</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2026_barocelli.php">20020250300109BA</a><br>
                      </strong></p></td>
                      <td><p>Barocelli, Sergio Sebasti&aacute;n</p></td>
                      <td> <p>Impactos de la inteligencia artificial en el mercado de consumo en argentina: desaf&iacute;os jur&iacute;dicos en materia de protecci&oacute;n de consumidores y regulaci&oacute;n de tecnolog&iacute;as emergentes </p></td>
                      <td><p>1/1/2026</p></td>
                      <td><p>31/12/2028</p></td>
                    </tr>
                    <tr>
                      <td><p><strong>20020250100189BA</strong></p></td>
                      <td><p>Beloff, Mary Ana</p></td>
                      <td><p>Los m&uacute;ltiples sentidos del jus puniendi en el derecho internacional de los derechos humanos	</p></td>
                      <td><p>1/1/2026 </p></td>
                      <td><p>31/12/2028</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2026_bercholc.php">20020250300148BA</a></strong></p></td>
                      <td><p>Bercholc, Jorge </p></td>
                      <td><p>Justicia y pol&iacute;tica. Las relaciones institucionales a trav&eacute;s de un estudio comparado de la performance de los tribunales constitucionales y cortes supremas de la Argentina, Alemania, Canad&aacute;, Espa&ntilde;a y Brasil en ejercicio del control de constitucionalidad. </p></td>
                      <td><p>1/1/2026</p></td>
                      <td><p>31/12/2028</p></td>
                    </tr>
                    <tr>
                      <td><p><strong>20020250100137BA</strong></p></td>
                      <td><p>Cl&eacute;rico, Mar&iacute;a Laura - Cardinaux, Nancy Susana</p></td>
                      <td><p>Los usos del derecho internacional de los derechos humanos por los tribunales superiores judiciales de las provincias y de la ciudad de Buenos Aires. </p></td>
                      <td><p>1/1/2026 </p></td>
                      <td><p>31/12/2028</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2026_corti.php">20020250300083BA</a></strong></p></td>
                      <td><p>Corti, Horacio Guillermo Anibal - Schafrik, Fabiana Hayde&eacute;</p></td>
                      <td><p>Pol&iacute;tica fiscal, derecho internacional de los derechos humanos y derecho internacional financiero </p></td>
                      <td><p>1/1/2026</p></td>
                      <td><p>31/12/2028</p></td>
                    </tr>
                    <tr>
                      <td><p><strong>20020250100112BA	</strong></p></td>
                      <td><p>De Fazio, Federico Leandro </p></td>
                      <td><p>Analog&iacute;a jur&iacute;dica. Hacia una elucidaci&oacute;n no-reduccionista </p></td>
                      <td><p>1/1/2026 </p></td>
                      <td><p>31/12/2028</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2026_lerman.php">20020250300044BA</a></strong></p></td>
                      <td><p>Lerman, Marcelo David </p></td>
                      <td><p>El estado de necesidad justificante: fundamento, l&iacute;mite y casos problem&aacute;ticos </p></td>
                      <td><p>1/1/2026 </p></td>
                      <td><p>31/12/2028</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2026_lescano.php">20020250100141BA</a></strong></p></td>
                      <td><p>Lescano Galardi, Ver&oacute;nica In&eacute;s </p></td>
                      <td><p>La conformaci&oacute;n del pensamiento jur&iacute;dico argentino a trav&eacute;s de las tesis de grado y doctorado de las abogadas egresadas de la facultad de derecho de la universidad de buenos aires (1910-1930) </p></td>
                      <td><p>1/1/2026 </p></td>
                      <td><p>31/12/2028</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2026_maisley.php">20020250300118BA</a></strong></p></td>
                      <td><p>Maisley, Nahuel - Alegre, Marcelo </p></td>
                      <td><p>Interdependencias en disputa: desaf&iacute;os a la normatividad del derecho p&uacute;blico en las crisis globales de las instituciones democr&aacute;ticas y del orden internacional </p></td>
                      <td><p>1/1/2026 </p></td>
                      <td><p>31/12/2028</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_decyt_2026_sarrabayrouse.php">20020250100142BA</a></strong></p></td>
                      <td><p>Sarrabayrouse, Eugenio Carlos - De Langhe, Marcela </p></td>
                      <td><p>Medio ambiente y derecho penal </p></td>
                      <td><p>1/1/2026 </p></td>
                      <td><p>31/12/2028</p></td>
                    </tr>
                    <tr>
                      <td><p><strong>20020250300108BA	</strong></p></td>
                      <td><p>Scherlis, Gerardo Dni - Pericola, Mar&iacute;a Alejandra </p></td>
                      <td><p>El derecho de los partidos pol&iacute;ticos en la jurisprudencia latinoamericana. Cambios y continuidades </p></td>
                      <td><p>1/1/2026 </p></td>
                      <td><p>31/12/2028</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2026_soto.php">20020250100164BA</a></strong></p></td>
                      <td><p>Soto, Alfredo Mario</p></td>
                      <td><p>El relacionamiento externo del mercosur: la regla de la negociaci&oacute;n conjunta y la reconfiguraci&oacute;n posible de los objetivos originarios de la integraci&oacute;n. </p></td>
                      <td><p>1/1/2026 </p></td>
                      <td><p>31/12/2028</p></td>
                    </tr>
                    <tr>
                      <td>                      <p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2026_vallet.php">20020250100118BA</a><br>
                      </strong></p></td>
                      <td><p>Vallet, Hilda Eleonora</p></td>
                      <td><p>El acceso a la justicia de las personas mayores v&iacute;ctimas de diferentes modalidades de violencia. a) Los casos de los mayores que cuidan a otros mayores. b) La situaci&oacute;n de los mayores LGTBIQ+ </p></td>
                      <td><p>1/1/2026 </p></td>
                      <td><p>31/12/2028</p></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td><p><a href="investigacion/inv_proyectos_vigentes_ubacyt_2023_aguirre.php"><strong>20020220300246BA</strong></a></p></td>
                      <td><p>Aguirre, Gonzalo Sebasti&aacute;n </p></td>
                      <td><p>Jurisprudencia ampliada y performance jur&iacute;dica ante las nuevas formas de nomopoiesis digital: persona jur&iacute;dica y sujeto de derecho entre individualidad y dividualidad </p></td>
                      <td><p>01/01/2023 </p></td>
                      <td><p>31/12/2025</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2023_capaldo.php">20020220200023BA</a></strong></p></td>
                      <td><p>Capaldo, Griselda Delia </p></td>
                      <td><p>Derecho de la navegaci&oacute;n: hacia un aggiornamento de las instituciones comunes y diferenciadas en cuestiones aeron&aacute;uticas y mar&iacute;timas. An&aacute;lisis jur&iacute;dico, sociol&oacute;gico y ambiental </p></td>
                      <td><p>01/01/2023 </p></td>
                      <td><p>31/12/2025</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2023_castillo.php">20020220200184BA</a></strong></p></td>
                      <td><p>Castillo Arga&ntilde;ar&aacute;s, Luis Fernando </p></td>
                      <td><p>Cambio clim&aacute;tico en argentina: aspectos jur&iacute;dicos, pol&iacute;ticos, de relaciones internacionales y ecol&oacute;gicos, con &eacute;nfasis en ecosistemas fluviales y costeros y la liberalizaci&oacute;n econ&oacute;mica </p></td>
                      <td><p>01/01/2023 </p></td>
                      <td><p>31/12/2025</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2023_cordoba.php">20020220300257BA</a></strong></p></td>
                      <td><p>Cordoba, Marcos Mauricio </p></td>
                      <td><p>El cuerpo humano y los avances tecnol&oacute;gicos </p></td>
                      <td><p>01/01/2023 </p></td>
                      <td><p>31/12/2025</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2023_dauria.php">20020220300179BA</a></strong></p></td>
                      <td><p>D&rsquo;Auria, An&iacute;bal Am&eacute;rico -<br>
                      Balerdi, Juan Carlos </p></td>
                      <td><p>El lenguaje de la pol&iacute;tica y las pol&iacute;ticas del lenguaje (o c&oacute;mo hacer pol&iacute;tica con palabras) </p></td>
                      <td><p>01/01/2023</p></td>
                      <td><p>31/12/2025</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2023_ferrer.php">20020220300170BA</a></strong></p></td>
                      <td><p>Ferrer, Esther Haydee Silvia -<br>
                      Garrido Cordobera, Lidia Maria Rosa </p></td>
                      <td><p>Vulnerabilidad, inteligencia artificial, transhumanismo y riesgo del desarrollo. La sociedad de la incertidumbre y el mercado. Los posibles da&ntilde;os: &eacute;tica y/o eficiencia.	</p></td>
                      <td><p>01/01/2023 </p></td>
                      <td><p>31/12/2025</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2023_lora.php">20020220300253BA</a></strong></p></td>
                      <td><p>Lora, Laura Noemi </p></td>
                      <td><p>Derecho y sociedad: teor&iacute;a y pr&aacute;cticas para el abordaje de los conflictos transversales a la ni&ntilde;ez y la adolescencia. </p></td>
                      <td><p>01/01/2023 </p></td>
                      <td><p>31/12/2025</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2023_scotti.php">20020220300015BA</a></strong></p></td>
                      <td><p>Scotti, Luciana Beatriz</p></td>
                      <td><p>Una relectura del Derecho Internacional Privado argentino en clave de multiculturalidad </p></td>
                      <td><p>01/01/2023 </p></td>
                      <td><p>31/12/2025</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2023_vita.php">20020220200022BA</a></strong></p></td>
                      <td><p>Vita, Leticia</p></td>
                      <td> <p>La reforma constitucional de 1957: un estudio de las expectativas y reclamos de derechos de los sectores populares a partir de las peticiones dirigidas a la asamblea constituyente </p></td>
                      <td><p>01/01/2023 </p></td>
                      <td><p>31/12/2025</p></td>
                    </tr>
                    <tr>
                      <td>                      <p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2023_wierzba.php">20020220100260BA</a></strong><br>
                      </p></td>
                      <td><p>Wierzba, Sandra Mabel </p></td>
                      <td><p>Vulnerables en las redes: c&oacute;mo prevenir y resarcir da&ntilde;os en las comunidades digitales</p></td>
                      <td><p>01/01/2023 </p></td>
                      <td><p>31/12/2025</p></td>
                    </tr>
                    <tr>
                      <td><p>&nbsp;</p></td>
                      <td><p>&nbsp;</p></td>
                      <td><p>&nbsp;</p></td>
                      <td><p>&nbsp;</p></td>
                      <td><p>&nbsp;</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2020_abelenda.php">20020190100038BA</a></strong></p></td>
                      <td><p><a href="/investigacion/investigadores/cv/virginia-abelenda.php">Abelenda, Virginia</a></p></td>
                      <td><p>La defensa de la amoenitas del fundo y del 'nuevo' 'derecho al paisaje' y otros intereses inmateriales. Bases jur&iacute;dicas romanas de tutela de intereses colectivos	</p></td>
                      <td><p>01/01/2020 </p></td>
                      <td><p>31/12/2023</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2020_alegre-gargarella.php">20020190100377BA</a></strong></p></td>
                      <td><p><a href="/investigacion/investigadores/cv/marcelo-alegre.php">Alegre, Marcelo</a><br>
                      <a href="/investigacion/investigadores/cv/roberto-gargarella.php">Gargarella, Roberto</a></p></td>
                      <td><p>Principio de Autonom&iacute;a e Igualdad y Teor&iacute;a de la Democracia </p></td>
                      <td><p>01/01/2020	</p></td>
                      <td><p>31/12/2023</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2020_beloff.php">20020190100385BA</a></strong></p></td>
                      <td><p><a href="/investigacion/investigadores/cv/mary-beloff.php">Beloff, Mary Ana</a></p></td>
                      <td><p>Ni&ntilde;as invisibles: vulnerabilidades m&uacute;ltiples y protecciones cruzadas en la justicia juvenil </p></td>
                      <td><p>01/01/2020	</p></td>
                      <td><p>31/12/2023</p></td>
                    </tr>
                    <tr>
                      <td><p><strong> <a href="investigacion/inv_proyectos_vigentes_ubacyt_2020_bercholc.php">20020190100149BA</a></strong></p></td>
                      <td><p><a href="/investigacion/investigadores/cv/jorge-omar-bercholc.php">Bercholc, Jorge</a></p></td>
                      <td><p>Justicia y Pol&iacute;tica. Las relaciones institucionales a trav&eacute;s de un estudio comparado de la performance de los Tribunales Constitucionales y Cortes Supremas de la Argentina, Alemania, Canad&aacute;, Espa&ntilde;a y Brasil en el ejercicio del control de constitucionalidad</p></td>
                      <td><p>01/01/2020	</p></td>
                      <td><p>31/12/2023</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2020_clerico.php">20020190100313BA</a></strong></p></td>
                      <td><p>Cl&eacute;rico, Mar&iacute;a Laura<br>
                      Cardinaux, Nancy Susana	</p></td>
                      <td><p>Interpretaci&oacute;n y adjudicaci&oacute;n en casos sobre derechos humanos en los Superiores Tribunales de Justicia Provinciales y de la CABA. Las culturas judiciales en perspectiva comparada provincial.	</p></td>
                      <td><p>01/01/2020 </p></td>
                      <td><p>31/12/2023</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2020_gastron.php">20020190100104BA</a></strong></p></td>
                      <td><p><a href="/investigacion/investigadores/cv/andrea-gastron.php">Gastron, Andrea Laura</a></p></td>
                      <td><p>Con los ojos de la ley: Representaciones art&iacute;sticas pl&aacute;sticas en el espacio p&uacute;blico y semi-p&uacute;blico de Buenos Aires y su relaci&oacute;n con el derecho </p></td>
                      <td><p>01/01/2020 </p></td>
                      <td><p>31/12/2023</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2020_gerlero.php">20020190100139BA</a></strong></p></td>
                      <td><p><a href="/investigacion/investigadores/cv/mario-gerlero.php">Gerlero, Mario Silvio</a></p></td>
                      <td><p>Derechos, redes y movilizaci&oacute;n social:Acciones, desaf&iacute;os y proyecci&oacute;n del Colectivo LGTBQ frente a la persistencia de los dispositivos de g&eacute;nero y sexualidad en las Instituciones Jur&iacute;dicas </p></td>
                      <td><p>01/01/2020 </p></td>
                      <td><p>31/12/2023</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2020_herrera.php">20020190100232BA</a></strong></p></td>
                      <td><p><a href="/investigacion/investigadores/cv/marisa-herrera.php">Herrera, Marisa</a><br>
                      Grosman, Cecilia	</p></td>
                      <td><p>Las guardas de hecho y su prohibici&oacute;n. Un estudio sociojur&iacute;dico desde el derecho contempor&aacute;neo		</p></td>
                      <td><p>01/01/2020</p></td>
                      <td><p>31/12/2023</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2020_lerman.php">20020190100143BA</a></strong></p></td>
                      <td><p><a href="/investigacion/investigadores/cv/marcelo-david-lerman.php">Lerman, Marcelo David</a></p></td>
                      <td><p>Sobre el cuestionamiento a la distinci&oacute;n entre il&iacute;cito y culpabilidad en la obra de Michael Pawlik. An&aacute;lisis de las consecuencias dogm&aacute;ticas de la renuncia a un concepto de il&iacute;cito independiente de la culpabildad	</p></td>
                      <td><p>01/01/2020	</p></td>
                      <td><p>31/12/2023</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2020_lescano.php">20020190100277BA</a></strong></p></td>
                      <td><p><a href="/investigacion/investigadores/cv/veronica-lescano-galardi.php">Lescano Galardi, Ver&oacute;nica In&eacute;s</a></p></td>
                      <td><p>La presencia de la mujer en la Facultad de Derecho de la Universidad de Buenos Aires y en la Generaci&oacute;n de 1910 y los cambios sociales, culturales y normativos que ello comport&oacute; en la realidad argentina. </p></td>
                      <td><p>01/01/2020	</p></td>
                      <td><p>31/12/2023</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2020_mastache.php">20020190100066BA</a></strong></p></td>
                      <td><p><a href="/investigacion/investigadores/cv/anahi-mastache.php">Mastache, Anah&iacute; Viviana</a></p></td>
                      <td><p>Formaci&oacute;n ciudadana en escuelas secundarias </p></td>
                      <td><p>01/01/2020	</p></td>
                      <td><p>31/12/2023</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2020_noodt.php">20020190100025BA</a></strong></p></td>
                      <td><p><a href="/investigacion/investigadores/cv/maria-blanca-noodt-taquela.php">Noodt Taquela, Mar&iacute;a Blanca</a></p></td>
                      <td><p>El Derecho internacional privado como ejercicio &eacute;tico y del pluralismo </p></td>
                      <td><p>01/01/2020 </p></td>
                      <td><p>31/12/2023</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2020_scherlis.php">20020190100144BA</a></strong></p></td>
                      <td><p><a href="/investigacion/investigadores/cv/gerardo-scherlis.php">Scherlis, Gerardo</a></p></td>
                      <td><p>Paradigmas normativos y jurisprudencia sobre partidos pol&iacute;ticos en Am&eacute;rica Latina </p></td>
                      <td><p>01/01/2020 </p></td>
                      <td><p>31/12/2023</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2020_seda.php">20020190100012BA</a></strong></p></td>
                      <td><p><a href="/investigacion/investigadores/cv/juan-antonio-seda.php">Seda, Juan Antonio</a></p></td>
                      <td><p>Derechos sucesorios de las personas con discapacidad. Armonizaci&oacute;n entre el C&oacute;digo Civil y Comercial y la Convenci&oacute;n sobre los Derechos de las Personas con Discapacidad.	</p></td>
                      <td><p>01/01/2020	</p></td>
                      <td><p>31/12/2023</p></td>
                    </tr>
                  </tbody>
                </table>
                <p><strong>MODALIDAD II</strong></p>
                <table class="table table-bordered table-striped">
                  <thead>
                    <tr class="celeste">
                      <th width="16%">C&oacute;digo</th>
                      <th width="21%">Director/a - Codirector/a </th>
                      <th width="43%">T&iacute;tulo</th>
                      <th width="9%">Inicio</th>
                      <th width="11%">Finalizaci&oacute;n</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2026_riera.php">20020250500140BA</a><br>
                      </strong></p></td>
                      <td><p>Riera, Ramiro - Sandri Fuentes, Anabella </p></td>
                      <td><p>El problema de la costumbre internacional sobre derechos humanos en el sistema de fuentes de la constituci&oacute;n nacional </p></td>
                      <td><p>1/1/2026 </p></td>
                      <td><p>31/12/2027</p></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2023_belardo.php">20020220400058BA</a></strong></p></td>
                      <td><p>Belardo, Marcela Beatriz</p></td>
                      <td><p>La agenda latinoamericana en salud: organismos regionales, pol&iacute;ticas sanitarias y la influencia del pensamiento cr&iacute;tico en la regi&oacute;n.</p></td>
                      <td><p>01/01/2023 </p></td>
                      <td><p>31/12/2024</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2023_corti.php">20020220400390BA</a></strong></p></td>
                      <td><p>Corti, Horacio Guillermo An&iacute;bal - <br>
                      Schafrik, Fabiana Hayde&eacute;</p></td>
                      <td><p>Pol&iacute;tica fiscal y Derecho Internacional de los Derechos Humanos: principios y directrices </p></td>
                      <td><p>01/01/2023 </p></td>
                      <td><p>31/12/2024</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2023_maisley.php">20020220400007BA</a></strong></p></td>
                      <td><p>Maisley, Nahuel </p></td>
                      <td><p>Mecanismos de regulaci&oacute;n p&uacute;blica en la gobernanza global: oportunidades y desaf&iacute;os para su democratizaci&oacute;n </p></td>
                      <td><p>01/01/2023 </p></td>
                      <td><p>31/12/2024</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2023_riera.php">20020220400026BA</a></strong></p></td>
                      <td><p>Riera, Ramiro </p></td>
                      <td><p>La din&aacute;mica actual de la Convenci&oacute;n para la Eliminaci&oacute;n de Todas las Formas de Discriminaci&oacute;n Racial y su proyecci&oacute;n en otros instrumentos internacionales de derechos humanos </p></td>
                      <td><p>01/01/2023 </p></td>
                      <td><p>31/12/2024</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2023_sancari.php">20020220400070BA</a></strong></p></td>
                      <td><p>Sancari, Sebastian </p></td>
                      <td><p>Un estudio comparado sobre la implementaci&oacute;n de las audiencias p&uacute;blicas en las Cortes Supremas, Cortes Constitucionales y Supremos Tribunales Constitucionales de Argentina, Colombia y Brasil. </p></td>
                      <td><p>01/01/2023 </p></td>
                      <td><p>31/12/2024</p></td>
                    </tr>
                    <tr>
                      <td><p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2023_soto.php">20020220400245BA</a></strong></p></td>
                      <td><p>Soto, Alfredo Mario</p></td>
                      <td><p>El acuerdo de asociaci&oacute;n entre el MERCOSUR y la Uni&oacute;n Europea: an&aacute;lisis de sus implicancias y el rol de las asimetr&iacute;as intrarregionales. </p></td>
                      <td><p>01/01/2023 </p></td>
                      <td><p>31/12/2024</p></td>
                    </tr>
                    <tr>
                      <td>                      <p><strong><a href="investigacion/inv_proyectos_vigentes_ubacyt_2023_vallet.php">20020220400199BA</a></strong><br>
                      </p></td>
                      <td><p>Vallet, Hilda Eleonora</p></td>
                      <td><p>Exclusiones como modalidad de la violencia contra el adulto mayor: a) las brechas digitales, b) la situaci&oacute;n de los adultos mayores LGTBIQ+ </p></td>
                      <td><p>01/01/2023 </p></td>
                      <td><p>31/12/2024</p></td>
                    </tr>
                  </tbody>
                </table>
                <p><strong>Proyectos finalizados</strong></p>
                <ul class="listaLinks">
                  <li><a href="investigacion/inv_prog_ubacyt_proyectos_2020.php">Proyectos de Investigaci&oacute;n 2020</a></li>
                    <li><a href="investigacion/inv_prog_ubacyt_proyectos_2018.php">Proyectos de Investigaci&oacute;n 2018</a></li>
                    <li><a href="investigacion/inv_prog_ubacyt_proyectos_2017.php">Proyectos de Investigaci&oacute;n 2017</a></li>
                    <li><a href="investigacion/inv_prog_ubacyt_proyectos_2016.php">Proyectos de Investigaci&oacute;n 2016</a></li>
                    <li><a href="investigacion/inv_prog_ubacyt_proyectos_2014-2017.php">Proyectos de Investigaci&oacute;n 2014-2017</a></li>
                    <li><a href="investigacion/inv_prog_ubacyt_proyectos_2013-2016.php">Proyectos de Investigaci&oacute;n 2013-2016</a></li>
                    <li><a href="investigacion/inv_prog_ubacyt_proyectos_2012-2015.php">Proyectos de Investigaci&oacute;n 2012-2015</a></li>
                    <li><a href="investigacion/inv_prog_ubacyt_proyectos_2011-2014.php">Proyectos de Investigaci&oacute;n 2011-2014</a></li>
                    <li><a href="/investigacion/inv_prog_ubacyt_proyectos_2010.php">Proyectos de Investigaci&oacute;n 2010-2012</a></li>
                    <li><a href="/investigacion/inv_prog_ubacyt_proyectos_2008.php">Proyectos de Investigaci&oacute;n 2008-2010</a></li>
                    <li><a href="/investigacion/inv_prog_ubacyt_proyectos_2006.php">Proyectos de Investigaci&oacute;n 2006-2009</a></li>
                    <li><a href="/investigacion/inv_prog_ubacyt_proyectos.php">Proyectos de Investigaci&oacute;n 2004-2007</a><br>
                    </li>
                </ul>

            
                    </div>
                </div>
            </div>
        </main>
    </div>

    <footer id="footer">
    <div class="container">
        <div class="row py-5">
            <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
                <h5 class="text-3 mb-3 text-upper">Accesos directos</h5>
                <ul class="list list-icons list-icons-sm">
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/institucional/consejo-directivo/">Consejo Directivo</a></p>
                    </li>
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/institucional/deinteres/informes-de-gestion.php">Informes de gestión</a></p>
                    </li>
                    <li class="mb-1"> <i class="fa fa-chevron-right text-color-primary"></i>
                      <p class="m-0"><a href="/internacionales/programas-de-intercambio-estudiantil.php">Programas de intercambio estudiantil</a></p>
                    </li>
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/extension/programas-de-extension-universitaria.php">Programas de extensión</a></p>
                    </li>
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/extension/cursos">Cursos de extensión</a></p>
                    </li>
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/extension/becas/">Programa de becas</a>                    </p>
                    </li>
					<li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="https://www.derecho.uba.ar/publicaciones/pdf/programas-academicos-para-estudiantes-de-la-fd.pdf">Programas académicos</a>                    </p>
                    </li>
                </ul>
            </div>
            <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
                <h5 class="text-3 mb-3">Direcciones Útiles</h5>
                <ul class="list list-icons list-icons-lg">
                    <li class="mb-1">
                        <i title="Copiar Dirección" class="far fa-envelope text-color-primary"></i>
                        <p class="m-0"><a href="mailto:diralumnos@derecho.uba.ar">Estudiantes</a></p>
                    </li>
                    <li class="mb-1">
                        <i title="Copiar Dirección" class="far fa-envelope text-color-primary"></i>
                        <p class="m-0"><a href="mailto:areageneroest@derecho.uba.ar">Igualdad de género</a></p>
                    </li>
                    <li class="mb-1">
                        <i title="Copiar Dirección" class="far fa-envelope text-color-primary"></i>
                        <p class="m-0"><a href="mailto:posgrado@derecho.uba.ar">Posgrado</a></p>
                    </li>
                    <li class="mb-1">
                        <i title="Copiar Dirección" class="far fa-envelope text-color-primary"></i>
                        <p class="m-0"><a href="mailto:biblio@derecho.uba.ar">Biblioteca</a></p>
                    </li>
                </ul>
                <p class="mb-0"><a class="btn btn-xs btn-primary" href="index_contactenos.php">Directorio completo</a></p>
            </div>
            <div class="col-md-6 col-lg-4 mb-4 mb-md-0">
                <h5 class="text-3 mb-3 text-upper">Comunicación</h5>
                <p class="mb-1"><a href="/derechoaldia" class="text-4 link-hover-style-1">Derecho al Día</a></p>
              <p class="mb-1"><a href="/noticias" class="text-4 link-hover-style-1">Noticias</a></p>
                <p class="mb-1"><a href="/agenda" class="text-4 link-hover-style-1">Agenda</a></p>
                <p class="mb-1"><a href="/institucional/deinteres/convocatorias-vigentes.php" class="text-4 link-hover-style-1">Convocatorias</a></p>
                <p class="mb-1"><a href="https://docs.google.com/forms/d/e/1FAIpQLSdOC8BRpzHpWM6FE3LwhLRlD6PB5TEl1Bfv1KNg9syhZzteIA/viewform?usp=header" target="_blank" class="btn btn-xs btn-primary">Suscripción al news</a></p>
            </div>
        </div>
    </div>
    <div class="footer-copyright">
        <div class="container py-2">
            <div class="row py-4">
                <div class="col-lg-1 d-flex align-items-center justify-content-center justify-content-lg-start mb-2 mb-lg-0">
                    <a href="index.html" class="logo pe-0 pe-lg-3">
                        <img alt="Facultad de Derecho Logo" src="/img/logo-footer.png" class="opacity-5" height="32">
                    </a>
                </div>
                <div class="col-lg-7 d-flex align-items-center justify-content-center justify-content-lg-start mb-4 mb-lg-0">
                    <p>Facultad de Derecho | <a href="">Universidad de Buenos Aires</a> | Av. Figueroa Alcorta 2263, CABA | 5287-6700</p>
                </div>
                <div class="col-lg-4 d-flex align-items-center justify-content-center justify-content-lg-end">
                    <nav id="sub-menu">
                        <ul class="footer-social-icons social-icons m-0">
                            <li class="social-icons-facebook">
                                <a href="https://www.facebook.com/DerechoUBA" target="_blank" title="Facebook de la Facultad de Derecho">
                                    <i class="fab fa-facebook-f text-2"></i>
                                </a>
                            </li>
                            <li class="social-icons-twitter">
                                <a href="https://www.x.com/DerechoUBA" target="_blank" title="Cuenta de X de la Facultad de Derecho">
                                    <i class="fab fa-x-twitter text-2"></i>
                                </a>
                            </li>
                            <li class="social-icons-instagram">
                                <a href="https://www.instagram.com/fduba/" target="_blank" title="Instagram de la Facultad de Derecho">
                                    <i class="fab fa-instagram text-2"></i>
                                </a>
                            </li>
                            <li class="social-icons-youtube">
                                <a href="https://www.youtube.com/user/DerechoUBA" target="_blank" title="Canal de Youtube de la Facultad de Derecho">
                                    <i class="fab fa-youtube text-2"></i>
                                </a>
                            </li>
                            <li class="social-icons-pinterest">
                                <a href="http://www.pinterest.com/derechouba" target="_blank" title="Pinterest de la Facultad de Derecho">
                                    <i class="fab fa-pinterest text-2"></i>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-3764422-1', 'auto');
  ga('send', 'pageview');
</script> -->


<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-ZH1YV4P5ML"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-ZH1YV4P5ML');
</script>
    <!-- Vendor -->
<script src="/vendor/plugins/js/plugins.min.js"></script>

<!-- Link a Iconos -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Theme Base, Components and Settings -->
<script src="/js/theme.js"></script>

<!-- Circle Flip Slideshow Script -->
<script src="/vendor/circle-flip-slideshow/js/jquery.flipshow.min.js"></script>

<!-- Current Page Views -->
<script src="/js/views/view.home.js"></script>

<!-- Current Page Vendor and Views -->
<script src="/js/views/view.contact.js"></script>

<script src="/vendor/swiped-events/swiped-events.js"></script>

<!-- Theme Custom -->
<script src="/js/main.js"></script>
<script src="/js/custom.js"></script>

<!-- Theme Initialization Files -->
<script src="/js/theme.init.js"></script>

<script>
    (function($) {

'use strict';

/*
Thumb Gallery
*/
theme.fn.intObs( '.thumb-gallery-wrapper', function(){
    var $thumbGalleryDetail = $(this).find('.thumb-gallery-detail'),
        $thumbGalleryThumbs = $(this).find('.thumb-gallery-thumbs'),
        flag = false,
        duration = 300;

    $thumbGalleryDetail
        .owlCarousel({
            items: 1,
            margin: 10,
            nav: true,
            dots: false,
            loop: true,
            autoHeight: true,
            navText: [],
            rtl: ( $('html').attr('dir') == 'rtl' ) ? true : false
        })
        .on('changed.owl.carousel', function(e) {
            if (!flag) {
                flag = true;
                $thumbGalleryThumbs.trigger('to.owl.carousel', [e.item.index-1, duration, true]);

                $thumbGalleryThumbs.find('.owl-item').removeClass('selected');
                $thumbGalleryThumbs.find('.owl-item').eq( e.item.index ).addClass('selected');
                flag = false;
            }
        });

    
    $thumbGalleryThumbs
        .owlCarousel({
            margin: 15,
            items: $(this).data('thumbs-items') ? $(this).data('thumbs-items') : 4,
            nav: false,
            center: $(this).data('thumbs-center') ? true : false,
            dots: false,
            rtl: ( $('html').attr('dir') == 'rtl' ) ? true : false
        })
        .on('click', '.owl-item', function() {
            $thumbGalleryDetail.trigger('to.owl.carousel', [$(this).index(), duration, true]);
        })
        .on('changed.owl.carousel', function(e) {
            if (!flag) {
                flag = true;
                $thumbGalleryDetail.trigger('to.owl.carousel', [e.item.index, duration, true]);
                flag = false;
            }
        });

    $thumbGalleryThumbs.find('.owl-item').eq(0).addClass('selected');
}, {});

}).apply(this, [jQuery]);
</script>
</body>

</html>