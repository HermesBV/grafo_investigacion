
<!DOCTYPE html>
<html lang="es">
<head>
    
    

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="author" content="kame-code.com">
<meta name="robots" content="index,follow">

<meta property="og:image" content="/img/logo/logo-media.png">
<meta property="og:image:type" content="image/png">
<meta property="og:image:width" content="363">
<meta property="og:image:height" content="363">

<!-- Mobile Specific Meta Tag-->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<!-- X TWITTER-->

<!-- Favicon and Apple Icons-->
<link rel="apple-touch-icon" sizes="57x57" href="/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon/favicon-16x16.png">
<link rel="manifest" href="/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<!-- Web Fonts  -->
<link id="googleFonts" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800%7CShadows+Into+Light&display=swap" rel="stylesheet" type="text/css">

<!-- Vendor CSS -->
<link rel="stylesheet" href="/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/vendor/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="/vendor/animate/animate.compat.css">
<link rel="stylesheet" href="/vendor/simple-line-icons/css/simple-line-icons.min.css">
<link rel="stylesheet" href="/vendor/owl.carousel/assets/owl.carousel.min.css">
<link rel="stylesheet" href="/vendor/owl.carousel/assets/owl.theme.default.min.css">
<link rel="stylesheet" href="/vendor/magnific-popup/magnific-popup.min.css">

<!-- Theme CSS -->
<link rel="stylesheet" href="/css/theme.css">
<link rel="stylesheet" href="/css/theme-elements.css">
<link rel="stylesheet" href="/css/theme-blog.css">
<link rel="stylesheet" href="/css/theme-shop.css">

<!-- Skin CSS -->
<link id="skinCSS" rel="stylesheet" href="/css/skins/derecho.css">

<!-- Theme Custom CSS -->
<link rel="stylesheet" href="/css/custom.css?1682693634">

<!-- Head Libs -->
<script src="/vendor/modernizr/modernizr.min.js"></script>

<base href="https://www.derecho.uba.ar" />
    <meta name="description" content="Facultad de Derecho de la Universidad de Buenos Aires">
    <title>Proyectos de Investigaci&oacute;n UBACYT 2004-2007 - Investigaci&oacute;n | Facultad de Derecho - Universidad de Buenos Aires</title>

</head>
<body class="cbp-spmenu-push" data-plugin-page-transition data-plugin-scroll-spy data-plugin-options="{'target': '#sidebar'}">
    <div class="body">
        <header id="header" class="header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': false, 'stickyChangeLogo': true, 'stickyStartAt': 30, 'stickyHeaderContainerHeight': 52}">
    <div class="header-body border-top-0">
        <div class="header-top">
            <div class="container">
                <div class="header-row py-md-2">
                    <div id="header-top-column" class="header-column justify-content-start">
                        <div class="header-row">
                            <nav id="header-nav-top" class="header-nav-top">
                                <ul class="nav nav-pills text-3">
                                    <li class="nav-item">
                                        <a class="nav-link ps-0 text-secondary" title="Información para ingresantes de la Facultad de Derecho" href="/ingresantes">
                                            Ingresantes
                                        </a>
                                    </li>
                                    <li class="nav-item nav-item-left-border">
                                        <a class="nav-link pe-0 text-secondary" title="Estudiantes de la Facultad de Derecho" href="/estudiantes">
                                            Estudiantes
                                        </a>
                                    </li>
                                    <li class="nav-item nav-item-left-border">
                                        <a class="nav-link ps-0 text-secondary" title="Docentes de la Facultad de Derecho" href="/docentes">
                                            Docentes
                                        </a>
                                    </li>
                                    <li class="nav-item nav-item-left-border">
                                        <a class="nav-link ps-0 text-secondary" title="Graduados de la Facultad de Derecho" href="/graduados">
                                            <span class="d-none d-sm-inline">Graduadas/os</span>
                                            <span class="d-inline d-sm-none">Graduadas</span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="header-column justify-content-end">
                        <div class="header-row">
                            <nav class="header-nav-top">
                                <ul class="nav nav-pills text-uppercase text-2">
                                  <li class="nav-item nav-item-anim-icon d-none d-md-block"><a class="nav-link pe-0" href="https://3w.derecho.uba.ar/" target="_blank">
                                      <i class="fas fa-angle-right"></i>
                                      SIU-Guaraní
                                  </a>                                  </li>
                                </ul>
                            </nav>
                            <div class="header-nav-features d-none d-md-block">
                                <div class="header-nav-features-search-reveal-container">
                                    <div class="header-nav-feature header-nav-features-search header-nav-features-search-reveal d-inline-flex">
                                        <a href="#" class="header-nav-features-search-show-icon d-inline-flex text-decoration-none"><i class="fas fa-search header-nav-top-icon"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="header-row">
                    <div class="header-nav-features header-nav-features-no-border p-static z-index-2">
                        <div class="header-nav-feature header-nav-features-search header-nav-features-search-reveal header-nav-features-search-reveal-big-search px-3">
                            <form role="search" class="d-flex w-100 h-100" action="/index_resbus.php" method="get" accept-charset="utf-8">
                                <div class="big-search-header input-group">
                                    <input class="form-control text-1" name="q" type="search" value="" placeholder="Buscar...">
                                    <input type="hidden" name="cx" value="007910097264156725590:4u2nbtj2ado">
                                    <input type="hidden" name="cof" value="FORID:11">
                                    <input type="hidden" name="ie" value="utf-8">
                                    <a href="#" class="header-nav-features-search-hide-icon"><i class="fas fa-times header-nav-top-icon"></i></a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-container container d-none d-md-flex">
            
            <div class="header-row">
                <div class="header-column justify-content-start justify-content-md-center order-1 order-md-2">
                    <div class="header-row">
                        <div class="header-logo justify-content-center">
                            <a href="/" title="Facultad de Derecho de la Universidad de Buenos Aires">
                                <img alt="Facultad de Derecho" width="371" height="52" data-sticky-width="307" data-sticky-height="43" src="/img/logo-header.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-nav-bar header-nav-bar-top-border">
            <div class="header-container container">
                <div class="header-row">
                    <div class="header-column justify-content-center d-flex d-md-none">
                        <a href="/" title="Facultad de Derecho de la Universidad de Buenos Aires">
                            <img alt="Facultad de Derecho" width="220" src="/img/logo-header.png">
                        </a>
                    </div>
                    <div class="header-column">
                        <div class="header-row justify-content-end">
                            <div class="header-nav p-0">
                                <div class="header-nav header-nav-links justify-content-lg-center">
                                    <div class="header-nav-main header-nav-main-square header-nav-main-dropdown-no-borders header-nav-main-dropdown-arrow header-nav-main-dropdown-center header-nav-main-dropdown-center-bottom header-nav-main-effect-3 header-nav-main-sub-effect-1">
                                        <nav class="collapse">
                                            <ul class="nav nav-pills" id="mainNav">
                                                <li><a href="/institucional">Institucional</a></li>
                                                <li><a href="/academica">Académica</a></li>
                                                <li><a href="/investigacion">Investigación</a></li>
                                                <li><a href="/extension">Extensión</a></li>
                                                <li><a href="/internacionales">Internacionales</a></li>
                                                <li><a href="/publicaciones">Publicaciones</a></li>
                                                <li><a href="/biblioteca">Biblioteca</a></li>
                                                <li><a href="/academica/posgrados">Posgrado</a></li>
                                            </ul>
                                            <div class="d-lg-none">        
                                                <form role="search" action="/index_resbus.php" id="cse-search-box" accept-charset="utf-8">
                                                    <div class="simple-search input-group">
                                                        <input class="form-control text-1" id="headerSearch" name="q" type="search" value="" placeholder="Buscar...">
                                                        <input type="hidden" name="cx" value="007910097264156725590:4u2nbtj2ado">
                                                        <input type="hidden" name="cof" value="FORID:11">
                                                        <input type="hidden" name="ie" value="utf-8">
                                                        <button class="btn" type="submit"> <i class="fas fa-search header-nav-top-icon text-color-dark"></i> </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </nav>
                                    </div>
                                    <button class="btn header-btn-collapse-nav" data-bs-toggle="collapse" data-bs-target=".header-nav-main nav">
                                        <i class="fas fa-bars"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="header-nav-features header-nav-features-no-border header-nav-features-lg-show-border order-1 order-lg-2">
                        <div class="header-nav-feature header-nav-features-search d-inline-flex">
                            <a href="#" class="header-nav-features-toggle text-decoration-none show-menu d-show d-md-none">
                                <span class="fa fa-outdent"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
        <main role="main" class="main">
            <nav id="menu-offcanvas" class="cbp-spmenu">
                <!-- Contenido Dinámico - No remover -->
            </nav>

            <section class="page-header page-header-modern bg-color-light-scale-1 page-header-sm">
                <div class="container">
                    <div class="row">
                        <div class="col-12 align-self-center">
                            <ul class="breadcrumb d-block">
                                
                <li><a href="/index.php">Inicio</a></li><li><a href="/investigacion/">Investigaci&oacute;n</a></li>
            
                            </ul>
                        </div>
                    </div>
                </div>
            </section>

            <div class="container my-3">
                <div class="row py-3">
                    <div class="col-lg-3 position-relative d-none d-lg-flex">
                        <nav class="sidebar" id="sidebar" data-plugin-sticky data-plugin-options="{'minWidth': 991, 'containerSelector': '.container', 'padding': {'top': 130}}">
                            <h5 class="font-weight-semi-bold">
                                Investigaci&oacute;n
                                <span class="fa fa-2x fa-times d-none hide-menu"></span>
                            </h5>
                            
                            
                    <ul class="nav nav-list flex-column mb-5"><li class="nav-item"><a href="investigacion/inv_institutos.php" class="nav-link">Institutos de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_proyectos_vigentes.php" class="nav-link">Proyectos de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_becarios.php" class="nav-link">Becarios/as de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_programas_estudiantes.php" class="nav-link">Programas para estudiantes</a></li>
<li class="nav-item"><a href="investigacion/inv_programas_docentes_investigadores.php" class="nav-link">Programas para docentes-investigadores/as</a></li>
<li class="nav-item"><a href="investigacion/investigacion_investigadores_visitantes.php" class="nav-link">Investigadores/as visitantes</a></li>
<li class="nav-item"><a href="investigacion/agenda/" class="nav-link">Agenda</a></li>
<li class="nav-item"><a href="investigacion/noticias/" class="nav-link">Noticias</a></li>
</ul><h5 class=" text-2 pt-4">Contacto</h5>
    <ul class="list list-icons list-icons-style-2 mt-2">
        <li><i class="fas fa-map-marker-alt top-6"></i>Primer Piso</li>
        <li><i class="fas fa-clock top-6"></i>Lunes a viernes 10 a 20 hs (atención telefónica) - Lunes a viernes 10 a 19 hs (atención presencial)</li>
        <li><i class="fas fa-phone top-6"></i> (5411) 5287-7096</li>
        <li><i class="fas fa-envelope top-6"></i> <a href="mailto:investigacion@derecho.uba.ar">investigacion@derecho.uba.ar</a></li>
    </ul>
<h5 class="text-2 pt-4">Redes</h5>
    <ul class="social-icons">
        <li class="social-icons-twitter"><a href="http://twitter.com/SI_DerechoUBA  " target="_blank"><i class="fab fa-twitter"></i></a></li>
        <li class="social-icons-instagram"><a href="https://www.instagram.com/si_derechouba/  " target="_blank"><i class="fab fa-instagram"></i></a></li>
        <li class="social-icons-youtube"><a href="https://www.youtube.com/channel/UCFz7MFrOGcFxkQbrItItzTw  " target="_blank"><i class="fab fa-youtube"></i></a></li>
    </ul>                
                            
                        </nav>
                    </div>
                    <div class="col-lg-9 contenido_pagina-col2">
                        
                
   <h1>Proyectos de Investigaci&oacute;n UBACYT 2004-2007 </h1>
    <p>      <strong>.: D002</strong></p>
    <p class="tabulado">Directora: Hebe Mabel Leonardi de Herb&oacute;n<br>
      Codirectora: Paula Constanza Sardegna<br>
  &quot;La participaci&oacute;n de los menores. Su inserci&oacute;n en la sociedad: El caso argentino&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D003</strong></p>
    <p class="tabulado">Director: Mario Justo L&oacute;pez<br>
      &quot;Transici&oacute;n, no consolidaci&oacute;n y quiebre de la democracia en la Argentina. 1916-1930&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D004</strong></p>
    <p class="tabulado">Director: Claudio Eduardo Martyniuk<br>
      Codirectora: Paula Viturro<br>
  &quot;Narraci&oacute;n y representaci&oacute;n de los cuerpos y la violencia&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D005</strong></p>
    <p class="tabulado">Director: Tulio Eduardo Ortiz<br>
      Codirectora: Mar&iacute;a Laura Pardo<br>
  &quot;Estado postmoderno y globalizaci&oacute;n. Transformaci&oacute;n del Estado Naci&oacute;n Argentino&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D006</strong></p>
    <p class="tabulado"> Director: Abelardo Levaggi<br>
      Codirector: Juan Carlos Frontera<br>
  &quot;'Federaci&oacute;n' y 'confederaci&oacute;n' en el discurso pol&iacute;tico argentino (1810-1860)&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D007</strong></p>
    <p class="tabulado">Director: David Baig&uacute;n<br>
      &quot;Dise&ntilde;o de nuevos mecanismos jur&iacute;dicos e institucionales de recuperaci&oacute;n de fondos econ&oacute;micos para el Estado: dise&ntilde;o de un modelo integrado para neutralizar la criminalidad econ&oacute;mica&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D009</strong></p>
    <p class="tabulado">Directora: Teodora Zamudio<br>
      Codirectores: Ana Mar&iacute;a Spadafora y Blanca Galimberti<br>
  &quot;R&eacute;gimen jur&iacute;dico de la explotaci&oacute;n y gesti&oacute;n de los recursos gen&eacute;ticos y del conocimiento tradicional asociado&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D010</strong></p>
    <p class="tabulado">Director: Salvador Bergel<br>
      &quot;Estado mundial de la protecci&oacute;n del consumidor&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D011</strong></p>
    <p class="tabulado">Director: Javier Buj&aacute;n<br>
      &quot;La c&aacute;rcel Argentina&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D012</strong></p>
    <p class="tabulado">Directora: Sara Feldstein de C&aacute;rdenas<br>
      Codirectora: Alicia Farinati<br>
  &quot;Armonizaci&oacute;n legislativa en materia de Derecho Comercial Internacional en el MERCOSUR, Chile y Bolivia&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D013</strong></p>
    <p class="tabulado">Director: Jorge Omar Bercholc<br>
      &quot;Un estudio emp&iacute;rico - cuantitativo de la instituci&oacute;n presidencial a trav&eacute;s del an&aacute;lisis de contenido de los discursos de apertura de las asambleas legislativas (1983-2007)&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D014</strong></p>
    <p class="tabulado">Director: Carlos Gustavo Gerscovich<br>
      &quot;La pesificaci&oacute;n en la emergencia: sentido, revisi&oacute;n judicial y consecuencias sobre las relaciones econ&oacute;micas&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D016</strong></p>
    <p class="tabulado">Directora: Cecilia Paulina Grosman<br>
      &quot;Bases para la armonizaci&oacute;n de la legislaci&oacute;n familiar en el MERCOSUR&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D017</strong></p>
    <p class="tabulado">Director: Roberto Mario Mordeglia<br>
      &quot;La seguridad jur&iacute;dica y la armonizaci&oacute;n de los procedimientos tributarios en el MERCOSUR&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D018</strong></p>
    <p class="tabulado">Directora: Griselda Delia Capaldo<br>
      Codirectores: Aurora Besal&uacute; Parkinson y Mar&iacute;a Cecilia G&oacute;mez Mas&iacute;a<br>
  &quot;Sinergias ambientales entre las aguas continentales y las mar&iacute;timas. De la prevenci&oacute;n a la responsabilidad y de las normas consuetudinarias al derecho sustantivo (con especial referencia a Sudam&eacute;rica y el MERCOSUR)&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D020</strong></p>
    <p class="tabulado">      Director: Ricardo Alberto Guibourg<br>
      &quot;An&aacute;lisis de criterios judiciales: la graduaci&oacute;n de la pena&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D021</strong></p>
    <p class="tabulado">Director: Marcela Alejandra Su&aacute;rez<br>
      Codirector: Mirta Beatriz &Aacute;lvarez<br>
  &quot;El procedimiento civil romano en el escenario de la comedia plautina&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D022</strong></p>
    <p class="tabulado">Directora: Patricia D&eacute;bora Sorokin<br>
      Codirectores: Mar&iacute;a Cecilia Andrade<br>
  &quot;Derechos personal&iacute;simos y prensa escrita entre 1983-2002: el caso de las personas viviendo con HIV / SIDA&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D023</strong></p>
    <p class="tabulado">Director: Marcos Mauricio C&oacute;rdoba Carrasco<br>
      Codirectora: Esther Hayde&eacute; Silvia Ferrer de Fern&aacute;ndez<br>
  &quot;Cuestiones derivadas del uso de t&eacute;cnicas de procreaci&oacute;n humana asistida que modifican los efectos naturales de la reproducci&oacute;n&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D024</strong></p>
    <p class="tabulado">Director: Agust&iacute;n Torres<br>
      &quot;Enfoque institucional y tributario para la armonizaci&oacute;n de los impuestos indirectos en el MERCOSUR&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D025</strong></p>
    <p class="tabulado">Directora: Beatr&iacute;z Rajland<br>
      Codirectores: Nelly Minyersky y Lily Rosa Flah<br>
  &quot;Reconocimiento de la salud y el ambiente como derechos humanos: requisito inexcusable de la calidad de vida humana. Responsabilidad del Estado y de los efectores privados de la salud y del derecho&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D026</strong></p>
    <p class="tabulado">Director: An&iacute;bal Am&eacute;rico D'Aur&iacute;a<br>
      Codirector: Juan Carlos Balerdi<br>
  &quot;El pensamiento jur&iacute;dico anarquista&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D027</strong></p>
    <p class="tabulado">Directora: Eve Rimoldi de Ladmann<br>
      Codirectora: Mar&iacute;a Blanca Noodt Taquela<br>
  &quot;Los nuevos procesos de integraci&oacute;n: los servicios profesionales en el MERCOSUR&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D028</strong></p>
    <p class="tabulado">Directora: Beatriz Azucena N&uacute;&ntilde;ez Santiago<br>
      &quot;Los sistemas agroalimentarios latinoamericanos y el desarrollo cient&iacute;fico tecnol&oacute;gico ante la pretendida funcionalidad del comercio mundial. Adecuaci&oacute;n de las pol&iacute;ticas p&uacute;blicas al desarrollo humano&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D029</strong></p>
    <p class="tabulado">Directora: Lidia Mar&iacute;a Rosa Garrido Cordobera<br>
      Codirectora: Ana Elena Margarita Kunz<br>
  &quot;Da&ntilde;os producidos por inundaciones. Percepci&oacute;n cuantificaci&oacute;n y prevenci&oacute;n: rol del Derecho y la trascendencia social (an&aacute;lisis del caso Santa F&eacute;)&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D031</strong></p>
    <p class="tabulado">Director: Arturo Pellet Lastra<br>
      Codirectora: Mar&iacute;a Elena Acosta<br>
  &quot;Los golpes de Estado en los gobiernos 'de facto' de la Argentina (1943-1983)&quot;</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D032</strong></p>
    <p><span class="tabulado">Directora: M&oacute;nica Pinto<br>
      Codirector: Pablo Luis Manili<br>
  &quot;Las fuentes del Derecho Internacional en la era de la globalizaci&oacute;n&quot;</span><br>
    </p>
    <h3>&nbsp;</h3>
<h3>&nbsp;</h3>

            
                    </div>
                </div>
            </div>
        </main>
    </div>

    <footer id="footer">
    <div class="container">
        <div class="row py-5">
            <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
                <h5 class="text-3 mb-3 text-upper">Accesos directos</h5>
                <ul class="list list-icons list-icons-sm">
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/institucional/consejo-directivo/">Consejo Directivo</a></p>
                    </li>
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/institucional/deinteres/informes-de-gestion.php">Informes de gestión</a></p>
                    </li>
                    <li class="mb-1"> <i class="fa fa-chevron-right text-color-primary"></i>
                      <p class="m-0"><a href="/internacionales/programas-de-intercambio-estudiantil.php">Programas de intercambio estudiantil</a></p>
                    </li>
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/extension/programas-de-extension-universitaria.php">Programas de extensión</a></p>
                    </li>
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/extension/cursos">Cursos de extensión</a></p>
                    </li>
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/extension/becas/">Programa de becas</a>                    </p>
                    </li>
					<li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="https://www.derecho.uba.ar/publicaciones/pdf/programas-academicos-para-estudiantes-de-la-fd.pdf">Programas académicos</a>                    </p>
                    </li>
                </ul>
            </div>
            <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
                <h5 class="text-3 mb-3">Direcciones Útiles</h5>
                <ul class="list list-icons list-icons-lg">
                    <li class="mb-1">
                        <i title="Copiar Dirección" class="far fa-envelope text-color-primary"></i>
                        <p class="m-0"><a href="mailto:diralumnos@derecho.uba.ar">Estudiantes</a></p>
                    </li>
                    <li class="mb-1">
                        <i title="Copiar Dirección" class="far fa-envelope text-color-primary"></i>
                        <p class="m-0"><a href="mailto:areageneroest@derecho.uba.ar">Igualdad de género</a></p>
                    </li>
                    <li class="mb-1">
                        <i title="Copiar Dirección" class="far fa-envelope text-color-primary"></i>
                        <p class="m-0"><a href="mailto:posgrado@derecho.uba.ar">Posgrado</a></p>
                    </li>
                    <li class="mb-1">
                        <i title="Copiar Dirección" class="far fa-envelope text-color-primary"></i>
                        <p class="m-0"><a href="mailto:biblio@derecho.uba.ar">Biblioteca</a></p>
                    </li>
                </ul>
                <p class="mb-0"><a class="btn btn-xs btn-primary" href="index_contactenos.php">Directorio completo</a></p>
            </div>
            <div class="col-md-6 col-lg-4 mb-4 mb-md-0">
                <h5 class="text-3 mb-3 text-upper">Comunicación</h5>
                <p class="mb-1"><a href="/derechoaldia" class="text-4 link-hover-style-1">Derecho al Día</a></p>
              <p class="mb-1"><a href="/noticias" class="text-4 link-hover-style-1">Noticias</a></p>
                <p class="mb-1"><a href="/agenda" class="text-4 link-hover-style-1">Agenda</a></p>
                <p class="mb-1"><a href="/institucional/deinteres/convocatorias-vigentes.php" class="text-4 link-hover-style-1">Convocatorias</a></p>
                <p class="mb-1"><a href="https://docs.google.com/forms/d/e/1FAIpQLSdOC8BRpzHpWM6FE3LwhLRlD6PB5TEl1Bfv1KNg9syhZzteIA/viewform?usp=header" target="_blank" class="btn btn-xs btn-primary">Suscripción al news</a></p>
            </div>
        </div>
    </div>
    <div class="footer-copyright">
        <div class="container py-2">
            <div class="row py-4">
                <div class="col-lg-1 d-flex align-items-center justify-content-center justify-content-lg-start mb-2 mb-lg-0">
                    <a href="index.html" class="logo pe-0 pe-lg-3">
                        <img alt="Facultad de Derecho Logo" src="/img/logo-footer.png" class="opacity-5" height="32">
                    </a>
                </div>
                <div class="col-lg-7 d-flex align-items-center justify-content-center justify-content-lg-start mb-4 mb-lg-0">
                    <p>Facultad de Derecho | <a href="">Universidad de Buenos Aires</a> | Av. Figueroa Alcorta 2263, CABA | 5287-6700</p>
                </div>
                <div class="col-lg-4 d-flex align-items-center justify-content-center justify-content-lg-end">
                    <nav id="sub-menu">
                        <ul class="footer-social-icons social-icons m-0">
                            <li class="social-icons-facebook">
                                <a href="https://www.facebook.com/DerechoUBA" target="_blank" title="Facebook de la Facultad de Derecho">
                                    <i class="fab fa-facebook-f text-2"></i>
                                </a>
                            </li>
                            <li class="social-icons-twitter">
                                <a href="https://www.x.com/DerechoUBA" target="_blank" title="Cuenta de X de la Facultad de Derecho">
                                    <i class="fab fa-x-twitter text-2"></i>
                                </a>
                            </li>
                            <li class="social-icons-instagram">
                                <a href="https://www.instagram.com/fduba/" target="_blank" title="Instagram de la Facultad de Derecho">
                                    <i class="fab fa-instagram text-2"></i>
                                </a>
                            </li>
                            <li class="social-icons-youtube">
                                <a href="https://www.youtube.com/user/DerechoUBA" target="_blank" title="Canal de Youtube de la Facultad de Derecho">
                                    <i class="fab fa-youtube text-2"></i>
                                </a>
                            </li>
                            <li class="social-icons-pinterest">
                                <a href="http://www.pinterest.com/derechouba" target="_blank" title="Pinterest de la Facultad de Derecho">
                                    <i class="fab fa-pinterest text-2"></i>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-3764422-1', 'auto');
  ga('send', 'pageview');
</script> -->


<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-ZH1YV4P5ML"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-ZH1YV4P5ML');
</script>
    <!-- Vendor -->
<script src="/vendor/plugins/js/plugins.min.js"></script>

<!-- Link a Iconos -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Theme Base, Components and Settings -->
<script src="/js/theme.js"></script>

<!-- Circle Flip Slideshow Script -->
<script src="/vendor/circle-flip-slideshow/js/jquery.flipshow.min.js"></script>

<!-- Current Page Views -->
<script src="/js/views/view.home.js"></script>

<!-- Current Page Vendor and Views -->
<script src="/js/views/view.contact.js"></script>

<script src="/vendor/swiped-events/swiped-events.js"></script>

<!-- Theme Custom -->
<script src="/js/main.js"></script>
<script src="/js/custom.js"></script>

<!-- Theme Initialization Files -->
<script src="/js/theme.init.js"></script>

<script>
    (function($) {

'use strict';

/*
Thumb Gallery
*/
theme.fn.intObs( '.thumb-gallery-wrapper', function(){
    var $thumbGalleryDetail = $(this).find('.thumb-gallery-detail'),
        $thumbGalleryThumbs = $(this).find('.thumb-gallery-thumbs'),
        flag = false,
        duration = 300;

    $thumbGalleryDetail
        .owlCarousel({
            items: 1,
            margin: 10,
            nav: true,
            dots: false,
            loop: true,
            autoHeight: true,
            navText: [],
            rtl: ( $('html').attr('dir') == 'rtl' ) ? true : false
        })
        .on('changed.owl.carousel', function(e) {
            if (!flag) {
                flag = true;
                $thumbGalleryThumbs.trigger('to.owl.carousel', [e.item.index-1, duration, true]);

                $thumbGalleryThumbs.find('.owl-item').removeClass('selected');
                $thumbGalleryThumbs.find('.owl-item').eq( e.item.index ).addClass('selected');
                flag = false;
            }
        });

    
    $thumbGalleryThumbs
        .owlCarousel({
            margin: 15,
            items: $(this).data('thumbs-items') ? $(this).data('thumbs-items') : 4,
            nav: false,
            center: $(this).data('thumbs-center') ? true : false,
            dots: false,
            rtl: ( $('html').attr('dir') == 'rtl' ) ? true : false
        })
        .on('click', '.owl-item', function() {
            $thumbGalleryDetail.trigger('to.owl.carousel', [$(this).index(), duration, true]);
        })
        .on('changed.owl.carousel', function(e) {
            if (!flag) {
                flag = true;
                $thumbGalleryDetail.trigger('to.owl.carousel', [e.item.index, duration, true]);
                flag = false;
            }
        });

    $thumbGalleryThumbs.find('.owl-item').eq(0).addClass('selected');
}, {});

}).apply(this, [jQuery]);
</script>
</body>

</html>