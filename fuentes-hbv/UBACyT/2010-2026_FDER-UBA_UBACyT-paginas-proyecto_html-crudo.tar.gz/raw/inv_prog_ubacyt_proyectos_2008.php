
<!DOCTYPE html>
<html lang="es">
<head>
    
    

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="author" content="kame-code.com">
<meta name="robots" content="index,follow">

<meta property="og:image" content="/img/logo/logo-media.png">
<meta property="og:image:type" content="image/png">
<meta property="og:image:width" content="363">
<meta property="og:image:height" content="363">

<!-- Mobile Specific Meta Tag-->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<!-- X TWITTER-->

<!-- Favicon and Apple Icons-->
<link rel="apple-touch-icon" sizes="57x57" href="/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon/favicon-16x16.png">
<link rel="manifest" href="/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<!-- Web Fonts  -->
<link id="googleFonts" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800%7CShadows+Into+Light&display=swap" rel="stylesheet" type="text/css">

<!-- Vendor CSS -->
<link rel="stylesheet" href="/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/vendor/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="/vendor/animate/animate.compat.css">
<link rel="stylesheet" href="/vendor/simple-line-icons/css/simple-line-icons.min.css">
<link rel="stylesheet" href="/vendor/owl.carousel/assets/owl.carousel.min.css">
<link rel="stylesheet" href="/vendor/owl.carousel/assets/owl.theme.default.min.css">
<link rel="stylesheet" href="/vendor/magnific-popup/magnific-popup.min.css">

<!-- Theme CSS -->
<link rel="stylesheet" href="/css/theme.css">
<link rel="stylesheet" href="/css/theme-elements.css">
<link rel="stylesheet" href="/css/theme-blog.css">
<link rel="stylesheet" href="/css/theme-shop.css">

<!-- Skin CSS -->
<link id="skinCSS" rel="stylesheet" href="/css/skins/derecho.css">

<!-- Theme Custom CSS -->
<link rel="stylesheet" href="/css/custom.css?1682693634">

<!-- Head Libs -->
<script src="/vendor/modernizr/modernizr.min.js"></script>

<base href="https://www.derecho.uba.ar" />
    <meta name="description" content="Facultad de Derecho de la Universidad de Buenos Aires">
    <title>Proyectos de Investigaci&oacute;n UBACYT 2008-2010 - Investigaci&oacute;n | Facultad de Derecho - Universidad de Buenos Aires</title>

</head>
<body class="cbp-spmenu-push" data-plugin-page-transition data-plugin-scroll-spy data-plugin-options="{'target': '#sidebar'}">
    <div class="body">
        <header id="header" class="header-effect-shrink" data-plugin-options="{'stickyEnabled': true, 'stickyEffect': 'shrink', 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': false, 'stickyChangeLogo': true, 'stickyStartAt': 30, 'stickyHeaderContainerHeight': 52}">
    <div class="header-body border-top-0">
        <div class="header-top">
            <div class="container">
                <div class="header-row py-md-2">
                    <div id="header-top-column" class="header-column justify-content-start">
                        <div class="header-row">
                            <nav id="header-nav-top" class="header-nav-top">
                                <ul class="nav nav-pills text-3">
                                    <li class="nav-item">
                                        <a class="nav-link ps-0 text-secondary" title="Información para ingresantes de la Facultad de Derecho" href="/ingresantes">
                                            Ingresantes
                                        </a>
                                    </li>
                                    <li class="nav-item nav-item-left-border">
                                        <a class="nav-link pe-0 text-secondary" title="Estudiantes de la Facultad de Derecho" href="/estudiantes">
                                            Estudiantes
                                        </a>
                                    </li>
                                    <li class="nav-item nav-item-left-border">
                                        <a class="nav-link ps-0 text-secondary" title="Docentes de la Facultad de Derecho" href="/docentes">
                                            Docentes
                                        </a>
                                    </li>
                                    <li class="nav-item nav-item-left-border">
                                        <a class="nav-link ps-0 text-secondary" title="Graduados de la Facultad de Derecho" href="/graduados">
                                            <span class="d-none d-sm-inline">Graduadas/os</span>
                                            <span class="d-inline d-sm-none">Graduadas</span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="header-column justify-content-end">
                        <div class="header-row">
                            <nav class="header-nav-top">
                                <ul class="nav nav-pills text-uppercase text-2">
                                  <li class="nav-item nav-item-anim-icon d-none d-md-block"><a class="nav-link pe-0" href="https://3w.derecho.uba.ar/" target="_blank">
                                      <i class="fas fa-angle-right"></i>
                                      SIU-Guaraní
                                  </a>                                  </li>
                                </ul>
                            </nav>
                            <div class="header-nav-features d-none d-md-block">
                                <div class="header-nav-features-search-reveal-container">
                                    <div class="header-nav-feature header-nav-features-search header-nav-features-search-reveal d-inline-flex">
                                        <a href="#" class="header-nav-features-search-show-icon d-inline-flex text-decoration-none"><i class="fas fa-search header-nav-top-icon"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="header-row">
                    <div class="header-nav-features header-nav-features-no-border p-static z-index-2">
                        <div class="header-nav-feature header-nav-features-search header-nav-features-search-reveal header-nav-features-search-reveal-big-search px-3">
                            <form role="search" class="d-flex w-100 h-100" action="/index_resbus.php" method="get" accept-charset="utf-8">
                                <div class="big-search-header input-group">
                                    <input class="form-control text-1" name="q" type="search" value="" placeholder="Buscar...">
                                    <input type="hidden" name="cx" value="007910097264156725590:4u2nbtj2ado">
                                    <input type="hidden" name="cof" value="FORID:11">
                                    <input type="hidden" name="ie" value="utf-8">
                                    <a href="#" class="header-nav-features-search-hide-icon"><i class="fas fa-times header-nav-top-icon"></i></a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-container container d-none d-md-flex">
            
            <div class="header-row">
                <div class="header-column justify-content-start justify-content-md-center order-1 order-md-2">
                    <div class="header-row">
                        <div class="header-logo justify-content-center">
                            <a href="/" title="Facultad de Derecho de la Universidad de Buenos Aires">
                                <img alt="Facultad de Derecho" width="371" height="52" data-sticky-width="307" data-sticky-height="43" src="/img/logo-header.png">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-nav-bar header-nav-bar-top-border">
            <div class="header-container container">
                <div class="header-row">
                    <div class="header-column justify-content-center d-flex d-md-none">
                        <a href="/" title="Facultad de Derecho de la Universidad de Buenos Aires">
                            <img alt="Facultad de Derecho" width="220" src="/img/logo-header.png">
                        </a>
                    </div>
                    <div class="header-column">
                        <div class="header-row justify-content-end">
                            <div class="header-nav p-0">
                                <div class="header-nav header-nav-links justify-content-lg-center">
                                    <div class="header-nav-main header-nav-main-square header-nav-main-dropdown-no-borders header-nav-main-dropdown-arrow header-nav-main-dropdown-center header-nav-main-dropdown-center-bottom header-nav-main-effect-3 header-nav-main-sub-effect-1">
                                        <nav class="collapse">
                                            <ul class="nav nav-pills" id="mainNav">
                                                <li><a href="/institucional">Institucional</a></li>
                                                <li><a href="/academica">Académica</a></li>
                                                <li><a href="/investigacion">Investigación</a></li>
                                                <li><a href="/extension">Extensión</a></li>
                                                <li><a href="/internacionales">Internacionales</a></li>
                                                <li><a href="/publicaciones">Publicaciones</a></li>
                                                <li><a href="/biblioteca">Biblioteca</a></li>
                                                <li><a href="/academica/posgrados">Posgrado</a></li>
                                            </ul>
                                            <div class="d-lg-none">        
                                                <form role="search" action="/index_resbus.php" id="cse-search-box" accept-charset="utf-8">
                                                    <div class="simple-search input-group">
                                                        <input class="form-control text-1" id="headerSearch" name="q" type="search" value="" placeholder="Buscar...">
                                                        <input type="hidden" name="cx" value="007910097264156725590:4u2nbtj2ado">
                                                        <input type="hidden" name="cof" value="FORID:11">
                                                        <input type="hidden" name="ie" value="utf-8">
                                                        <button class="btn" type="submit"> <i class="fas fa-search header-nav-top-icon text-color-dark"></i> </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </nav>
                                    </div>
                                    <button class="btn header-btn-collapse-nav" data-bs-toggle="collapse" data-bs-target=".header-nav-main nav">
                                        <i class="fas fa-bars"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="header-nav-features header-nav-features-no-border header-nav-features-lg-show-border order-1 order-lg-2">
                        <div class="header-nav-feature header-nav-features-search d-inline-flex">
                            <a href="#" class="header-nav-features-toggle text-decoration-none show-menu d-show d-md-none">
                                <span class="fa fa-outdent"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
        <main role="main" class="main">
            <nav id="menu-offcanvas" class="cbp-spmenu">
                <!-- Contenido Dinámico - No remover -->
            </nav>

            <section class="page-header page-header-modern bg-color-light-scale-1 page-header-sm">
                <div class="container">
                    <div class="row">
                        <div class="col-12 align-self-center">
                            <ul class="breadcrumb d-block">
                                
                <li><a href="/index.php">Inicio</a></li><li><a href="/investigacion/">Investigaci&oacute;n</a></li>
            
                            </ul>
                        </div>
                    </div>
                </div>
            </section>

            <div class="container my-3">
                <div class="row py-3">
                    <div class="col-lg-3 position-relative d-none d-lg-flex">
                        <nav class="sidebar" id="sidebar" data-plugin-sticky data-plugin-options="{'minWidth': 991, 'containerSelector': '.container', 'padding': {'top': 130}}">
                            <h5 class="font-weight-semi-bold">
                                Investigaci&oacute;n
                                <span class="fa fa-2x fa-times d-none hide-menu"></span>
                            </h5>
                            
                            
                    <ul class="nav nav-list flex-column mb-5"><li class="nav-item"><a href="investigacion/inv_institutos.php" class="nav-link">Institutos de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_proyectos_vigentes.php" class="nav-link">Proyectos de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_becarios.php" class="nav-link">Becarios/as de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_programas_estudiantes.php" class="nav-link">Programas para estudiantes</a></li>
<li class="nav-item"><a href="investigacion/inv_programas_docentes_investigadores.php" class="nav-link">Programas para docentes-investigadores/as</a></li>
<li class="nav-item"><a href="investigacion/investigacion_investigadores_visitantes.php" class="nav-link">Investigadores/as visitantes</a></li>
<li class="nav-item"><a href="investigacion/agenda/" class="nav-link">Agenda</a></li>
<li class="nav-item"><a href="investigacion/noticias/" class="nav-link">Noticias</a></li>
</ul><h5 class=" text-2 pt-4">Contacto</h5>
    <ul class="list list-icons list-icons-style-2 mt-2">
        <li><i class="fas fa-map-marker-alt top-6"></i>Primer Piso</li>
        <li><i class="fas fa-clock top-6"></i>Lunes a viernes 10 a 20 hs (atención telefónica) - Lunes a viernes 10 a 19 hs (atención presencial)</li>
        <li><i class="fas fa-phone top-6"></i> (5411) 5287-7096</li>
        <li><i class="fas fa-envelope top-6"></i> <a href="mailto:investigacion@derecho.uba.ar">investigacion@derecho.uba.ar</a></li>
    </ul>
<h5 class="text-2 pt-4">Redes</h5>
    <ul class="social-icons">
        <li class="social-icons-twitter"><a href="http://twitter.com/SI_DerechoUBA  " target="_blank"><i class="fab fa-twitter"></i></a></li>
        <li class="social-icons-instagram"><a href="https://www.instagram.com/si_derechouba/  " target="_blank"><i class="fab fa-instagram"></i></a></li>
        <li class="social-icons-youtube"><a href="https://www.youtube.com/channel/UCFz7MFrOGcFxkQbrItItzTw  " target="_blank"><i class="fab fa-youtube"></i></a></li>
    </ul>                
                            
                        </nav>
                    </div>
                    <div class="col-lg-9 contenido_pagina-col2">
                        
                
   <h1>Proyectos de Investigaci&oacute;n UBACYT 2008-2010</h1>
<p><strong>CONSOLIDADOS</strong></p>
    <p><strong>.:	D021</strong></p>
    <p class="tabulado">Sustentabilidad y gobernabilidad del agua en ecosistemas. An&aacute;lisis de gesti&oacute;n en el MERCOSUR y Colombia<br>
    Directora: Griselda Capaldo</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D019</strong></p>
    <p class="tabulado">El da&ntilde;o causado por los hechos violentos en el ambiente urbano. Percepci&oacute;n social, cuantificaci&oacute;n, responsabilidad y prevenci&oacute;n<br>
      Directora: Lidia Garrido Cordobera<br>
    Codirectora: Ana Kunz</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D017</strong></p>
    <p class="tabulado">El anarquismo, la genealog&iacute;a del Estado y la deconstrucci&oacute;n del discurso constitucionalista<br>
      Director: An&iacute;bal D&acute;Auria<br>
    Codirector: Juan Balerdi</p>
    <hr class="linea-turquesa">
    <p><strong>.: D016</strong></p>
    <p class="tabulado">El Federalismo fiscal argentino<br>
      Director: Jos&eacute; Cas&aacute;s<br>
    Codirector: Horacio Corti</p>
    <hr class="linea-turquesa">
    <p><strong>.: D008 </strong></p>
    <p class="tabulado"> Consolidaci&oacute;n del Estado Naci&oacute;n argentino. Rol de la intelligentsia de la &eacute;poca en particular de la Facultad de Derecho de la Universidad de Buenos Aires<br>
      Director: Tulio Ortiz</p>
    <hr class="linea-turquesa">
    <p><strong>.: D004</strong></p>
    <p class="tabulado">El Derecho Penal argentino en la historia<br>
      Director: Abelardo Levaggi</p>
    <hr class="linea-turquesa">
    <p><strong>.: D010 </strong></p>
    <p class="tabulado">El encarcelamiento en el campo punitivo. Representaciones y efectos sobre la pena<br>
      Director: Eugenio R. Zaffaroni</p>
    <hr class="linea-turquesa">
    <p><strong>.: D015</strong></p>
    <p class="tabulado">Derechos sexuales y reproductivos. Identidad sexual. Poder y marginalidad<br>
      Directora: Nelly Minyersky<br>
    Codirectora: Beatriz Rajland</p>
    <hr class="linea-turquesa">
    <p><strong>.: D012 </strong></p>
    <p class="tabulado">La justicia penal frente a los delitos atribuidos a personas menores de diecis&eacute;is a&ntilde;os de edad<br>
      Directora: Mary Beloff</p>
    <hr class="linea-turquesa">
    <p><strong>.: D007 </strong></p>
    <p class="tabulado">Investigaci&oacute;n para la creaci&oacute;n de principios y normas tendientes a coadyuvar al efectivo cumplimiento de los deberes de asistencia<br>
      Director: Marcos M. C&oacute;rdoba<br>
    Codirectora: Esther Ferrer de Fern&aacute;ndez</p>
    <hr class="linea-turquesa">
    <p><strong>.: D006 </strong></p>
    <p class="tabulado">Extranjerizaci&oacute;n de la delincuencia bancaria<br>
      Director: David Baig&uacute;n<br>
      Codirectora: Patricia Llerena</p>
    <hr class="linea-turquesa">
    <p><strong>.: D011</strong></p>
    <p class="tabulado">Fijaci&oacute;n del da&ntilde;o moral<br>
      Director: Ricardo Guibourg<br>
    Codirector: Ricardo Guarinoni</p>
    <hr class="linea-turquesa">
    <p><strong>.: D018 </strong></p>
    <p class="tabulado">Los procesos de integraci&oacute;n y los desaf&iacute;os del mundo actual<br>
      Directora: Eve Rimoldi de Ladmann<br>
    Codirector: Omar &Aacute;lvarez</p>
    <hr class="linea-turquesa">
    <p><strong>.: D001 </strong></p>
    <p class="tabulado">R&eacute;gimen jur&iacute;dico de la explotaci&oacute;n y gesti&oacute;n de los recursos gen&eacute;ticos y el conocimiento tradicional asociado<br>
      Directora: Teodora Zamudio<br>
    Codirectores: Mar&iacute;a Blanca Galimberti y Norma Raminger</p>
    <hr class="linea-turquesa">
    <p><strong>.: D002 </strong></p>
    <p class="tabulado">Las pol&iacute;ticas p&uacute;blicas de los gobiernos radicales. Su relaci&oacute;n con la consolidaci&oacute;n de la primera democracia argentina, 1916-1930<br>
    Director: Mario L&oacute;pez</p>
    <hr class="linea-turquesa">
    <p><strong>.: D003</strong></p>
    <p class="tabulado">La Naci&oacute;n y la Rep&uacute;blica en la Argentina de los &acute;40<br>
    Director: Arturo Pellet Lastra</p>
    <hr class="linea-turquesa">
    <p><strong>.: D020 </strong></p>
    <p class="tabulado">Derechos personal&iacute;simos y VIH/SIDA. Hacia una efectiva protecci&oacute;n de la informaci&oacute;n sensible<br>
    Directora: Patricia Sorokin</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D014</strong></p>
    <p class="tabulado">Temas de Derecho Privado en Roma a la luz de las comedias de plauto<br>
      Directora: Marcela Su&aacute;rez<br>
    Codirectora: Mirta &Aacute;lvarez</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p><strong>EN FORMACI&Oacute;N</strong></p>
    <p><strong>.:	D405</strong></p>
    <p class="tabulado">Respuestas normativas al impacto de los biocombustibles en la matriz productiva de alimentos y en el ordenamiento territorial<br>
      Directora: Marta Andrich de &Aacute;lvarez<br>
    Codirectores: Eduardo Pigretti y Dino Bellorio Clabot</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D401</strong></p>
    <p class="tabulado">Sobre los efectos de los fallos de la Corte Suprema de Justicia de la Argentina. Luces y sombras respecto de la adopci&oacute;n del efecto erga omnes.<br>
      Director: Ra&uacute;l Ferreyra</p>
    <hr class="linea-turquesa">
    <p><strong>.: D407</strong></p>
    <p class="tabulado">Fundamento de la responsabilidad del Estado. Su inserci&oacute;n en el marco de la Teor&iacute;a General del Derecho de Da&ntilde;os<br>
      Director: Alberto Bueres<br>
    Codirector: Sebasti&aacute;n Picasso</p>
    <hr class="linea-turquesa">
    <p><strong>.: D410</strong></p>
    <p class="tabulado">El financiamiento y las garant&iacute;as internacionales en el &aacute;mbito de las actividades espaciales. Aspectos jur&iacute;dicos internacionales<br>
      Director: Luis Castillo Arga&ntilde;ar&aacute;s</p>
    <hr class="linea-turquesa">
    <p><strong>.: D412</strong></p>
    <p class="tabulado">El cambio clim&aacute;tico: escenarios legales y desaf&iacute;os jur&iacute;dicos y pol&iacute;ticos en Argentina<br>
    Directora: Aurora Besal&uacute; Parkinson</p>
    <hr class="linea-turquesa">
    <p><strong>.: D419</strong></p>
    <p class="tabulado">Los d&eacute;ficit constitucionales del proceso judicial en que el Estado es parte. Propuesta de reformulaci&oacute;n en el marco de un anteproyecto de C&oacute;digo Procesal contencioso administrativo de la Naci&oacute;n<br>
    Director: Carlos Balb&iacute;n</p>
    <hr class="linea-turquesa">
    <p><strong>.: D403</strong></p>
    <p class="tabulado">Distribuci&oacute;n de riesgos en sociedad<br>
      Directora: Graciela Lovece</p>
    <hr class="linea-turquesa">
    <p><strong>.: D416</strong></p>
    <p class="tabulado">R&eacute;gimen jur&iacute;dico del turismo ambientalmente sustentable en Argentina. Estado del arte<br>
      Directora: Mar&iacute;a Cristina Zeballos de Sisto<br>
      Codirector: Alejandro Braga</p>
    <hr class="linea-turquesa">
    <p><strong>.: D414</strong></p>
    <p class="tabulado">Historia de las ideas jur&iacute;dicas en la Argentina: la circulaci&oacute;n de ideas jur&iacute;dicas en la Argentina, de la Rep&uacute;blica en formaci&oacute;n a la ilusi&oacute;n democr&aacute;tica (1862-1916). An&aacute;lisis comparativo con experiencias europeas y sudamericanas<br>
      Directora: Mar&iacute;a Rosa Pugliese</p>
    <hr class="linea-turquesa">
    <p><strong>.: D418</strong></p>
    <p class="tabulado">El legado procesal castellano-indiano: el caso de la ejecuci&oacute;n de sentencia en el Virreinato del R&iacute;o de la Plata y su proyecci&oacute;n en el Derecho Posterior<br>
    Directora: Viviana Kluger</p>
    <hr class="linea-turquesa">
    <p><strong>.: D417</strong></p>
    <p><span class="tabulado">Polic&iacute;a aut&oacute;noma y estrategias de control de seguridad. Estudio multidisciplinario del complejo &quot;polic&iacute;a-seguridad-prevenci&oacute;n&quot; en el &aacute;mbito de la Ciudad de Buenos Aires<br>
      Director: Gabriel Anitua<br>
      Codirector: Ignacio Tedesco</span><br>
  <br>
    </p>
    <hr class="linea-turquesa">
    <p><strong>.: D413</strong></p>
    <p class="tabulado">Perspectiva de derechos en el marco de la inclusi&oacute;n social. Posibilidades, alcances y desaf&iacute;os<br>
      Directora: Laura Pautassi<br>
      Codirector: Mario Gerlero</p>
    <hr class="linea-turquesa">
    <p><strong>.: D404</strong></p>
    <p class="tabulado">Las categor&iacute;as fundamentales del pensamiento pol&iacute;tico y el lugar del derecho dentro de ellas: un an&aacute;lisis hist&oacute;rico fenomenol&oacute;gico de su desarrollo<br>
      Director: Juan Videla Montilla<br>
      Codirector: Elizabeth Marum</p>
    <hr class="linea-turquesa">
    <p><strong>.: D424</strong></p>
    <p class="tabulado">Sociedad e instituciones. El modo de pensar la infancia<br>
      Directora: Laura Lora</p>
    <hr class="linea-turquesa">
    <p><strong>.: D411</strong></p>
    <p class="tabulado">La formaci&oacute;n docente en ciencias jur&iacute;dicas: dispositivos para la pr&aacute;ctica reflexiva<br>
      Directora: Rebecca Anijovich<br>
      Codirectora: Graciela Cappelletti</p>
    <hr class="linea-turquesa">
    <p><strong>.: D420</strong></p>
    <p class="tabulado">La pedagog&iacute;a jur&iacute;dica en la Universidad de Buenos Aires: estudio etnogr&aacute;fico de la ense&ntilde;anza del Derecho a trav&eacute;s del concepto de performance<br>
      Director: Fernando Fischman<br>
    Codirector: Juan Seda</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D408</strong></p>
    <p class="tabulado"> Prostituci&oacute;n: Estado de riesgo - libre albedr&iacute;o<br>
      Director: Javier Buj&aacute;n</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p><strong>J&Oacute;VENES INVESTIGADORES</strong></p>
    <p><strong>.: D601</strong></p>
    <p class="tabulado">El divorcio en la Argentina desde un enfoque socio jur&iacute;dico. Pr&aacute;cticas sociales y judiciales<br>
      Directora: Marisa Herrera</p>
    <hr class="linea-turquesa">
    <p><strong>.: D604</strong></p>
    <p class="tabulado">Los alcances normativos frente a los condicionantes f&aacute;cticos en el acceso a servicios p&uacute;blicos y la protecci&oacute;n de los usuarios<br>
    Directora: Laura P&eacute;rez Bustamante</p>
    <hr class="linea-turquesa">
    <p><strong>.: D603</strong></p>
    <p class="tabulado">Normativa y formas de comunicaci&oacute;n del trabajo no registrado. Un enfoque interdisciplinario para la disminuci&oacute;n del costo laboral de las PyMEs<br>
    Directora: Paula Sardegna</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D602</strong></p>
    <p class="tabulado">La opini&oacute;n p&uacute;blica a trav&eacute;s de la evoluci&oacute;n jurisprudencial de la Corte Suprema de Justicia de la Naci&oacute;n<br>
    Director: Sebasti&aacute;n Sancari.</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p><strong>EN FORMACI&Oacute;N Y CON ESTIPENDIO DE SOSTENIMIENTO</strong></p>
    <p><strong>.:	D406</strong></p>
    <p class="tabulado">Conflicto normativo en la aplicaci&oacute;n e interpretaci&oacute;n de las leyes 24.051 y 25.612 relativas a los residuos peligrosos industriales y su impacto en el ambiente.<br>
      Director: Jorge Atilio Franza<br>
    Codirector: Gustavo Gonz&aacute;lez Acosta</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D409</strong></p>
    <p class="tabulado">Proyecto de investigaci&oacute;n para la elaboraci&oacute;n de una nueva ley de prevenci&oacute;n de crisis concursales, su tratamiento y procesamiento judicial y extrajudicial.<br>
      Director: Arnoldo Kleidermacher<br>
    Codirector: Daniel Altmark</p>
    <hr class="linea-turquesa">
    <p><strong>.:	D415</strong></p>
    <p><span class="tabulado">&ldquo;Juicio a la corte&rdquo; Los abogados, la Corte Suprema de la Naci&oacute;n y el gobierno durante la crisis argentina 2001/2.<br>
      Director: Ferm&iacute;n Ubertone<br>
      Codirectora: Mar&iacute;a Cristina Girotti</span><br>
    </p>

            
                    </div>
                </div>
            </div>
        </main>
    </div>

    <footer id="footer">
    <div class="container">
        <div class="row py-5">
            <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
                <h5 class="text-3 mb-3 text-upper">Accesos directos</h5>
                <ul class="list list-icons list-icons-sm">
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/institucional/consejo-directivo/">Consejo Directivo</a></p>
                    </li>
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/institucional/deinteres/informes-de-gestion.php">Informes de gestión</a></p>
                    </li>
                    <li class="mb-1"> <i class="fa fa-chevron-right text-color-primary"></i>
                      <p class="m-0"><a href="/internacionales/programas-de-intercambio-estudiantil.php">Programas de intercambio estudiantil</a></p>
                    </li>
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/extension/programas-de-extension-universitaria.php">Programas de extensión</a></p>
                    </li>
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/extension/cursos">Cursos de extensión</a></p>
                    </li>
                    <li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="/extension/becas/">Programa de becas</a>                    </p>
                    </li>
					<li class="mb-1">
                        <i class="fa fa-chevron-right text-color-primary"></i>
                        <p class="m-0"><a href="https://www.derecho.uba.ar/publicaciones/pdf/programas-academicos-para-estudiantes-de-la-fd.pdf">Programas académicos</a>                    </p>
                    </li>
                </ul>
            </div>
            <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
                <h5 class="text-3 mb-3">Direcciones Útiles</h5>
                <ul class="list list-icons list-icons-lg">
                    <li class="mb-1">
                        <i title="Copiar Dirección" class="far fa-envelope text-color-primary"></i>
                        <p class="m-0"><a href="mailto:diralumnos@derecho.uba.ar">Estudiantes</a></p>
                    </li>
                    <li class="mb-1">
                        <i title="Copiar Dirección" class="far fa-envelope text-color-primary"></i>
                        <p class="m-0"><a href="mailto:areageneroest@derecho.uba.ar">Igualdad de género</a></p>
                    </li>
                    <li class="mb-1">
                        <i title="Copiar Dirección" class="far fa-envelope text-color-primary"></i>
                        <p class="m-0"><a href="mailto:posgrado@derecho.uba.ar">Posgrado</a></p>
                    </li>
                    <li class="mb-1">
                        <i title="Copiar Dirección" class="far fa-envelope text-color-primary"></i>
                        <p class="m-0"><a href="mailto:biblio@derecho.uba.ar">Biblioteca</a></p>
                    </li>
                </ul>
                <p class="mb-0"><a class="btn btn-xs btn-primary" href="index_contactenos.php">Directorio completo</a></p>
            </div>
            <div class="col-md-6 col-lg-4 mb-4 mb-md-0">
                <h5 class="text-3 mb-3 text-upper">Comunicación</h5>
                <p class="mb-1"><a href="/derechoaldia" class="text-4 link-hover-style-1">Derecho al Día</a></p>
              <p class="mb-1"><a href="/noticias" class="text-4 link-hover-style-1">Noticias</a></p>
                <p class="mb-1"><a href="/agenda" class="text-4 link-hover-style-1">Agenda</a></p>
                <p class="mb-1"><a href="/institucional/deinteres/convocatorias-vigentes.php" class="text-4 link-hover-style-1">Convocatorias</a></p>
                <p class="mb-1"><a href="https://docs.google.com/forms/d/e/1FAIpQLSdOC8BRpzHpWM6FE3LwhLRlD6PB5TEl1Bfv1KNg9syhZzteIA/viewform?usp=header" target="_blank" class="btn btn-xs btn-primary">Suscripción al news</a></p>
            </div>
        </div>
    </div>
    <div class="footer-copyright">
        <div class="container py-2">
            <div class="row py-4">
                <div class="col-lg-1 d-flex align-items-center justify-content-center justify-content-lg-start mb-2 mb-lg-0">
                    <a href="index.html" class="logo pe-0 pe-lg-3">
                        <img alt="Facultad de Derecho Logo" src="/img/logo-footer.png" class="opacity-5" height="32">
                    </a>
                </div>
                <div class="col-lg-7 d-flex align-items-center justify-content-center justify-content-lg-start mb-4 mb-lg-0">
                    <p>Facultad de Derecho | <a href="">Universidad de Buenos Aires</a> | Av. Figueroa Alcorta 2263, CABA | 5287-6700</p>
                </div>
                <div class="col-lg-4 d-flex align-items-center justify-content-center justify-content-lg-end">
                    <nav id="sub-menu">
                        <ul class="footer-social-icons social-icons m-0">
                            <li class="social-icons-facebook">
                                <a href="https://www.facebook.com/DerechoUBA" target="_blank" title="Facebook de la Facultad de Derecho">
                                    <i class="fab fa-facebook-f text-2"></i>
                                </a>
                            </li>
                            <li class="social-icons-twitter">
                                <a href="https://www.x.com/DerechoUBA" target="_blank" title="Cuenta de X de la Facultad de Derecho">
                                    <i class="fab fa-x-twitter text-2"></i>
                                </a>
                            </li>
                            <li class="social-icons-instagram">
                                <a href="https://www.instagram.com/fduba/" target="_blank" title="Instagram de la Facultad de Derecho">
                                    <i class="fab fa-instagram text-2"></i>
                                </a>
                            </li>
                            <li class="social-icons-youtube">
                                <a href="https://www.youtube.com/user/DerechoUBA" target="_blank" title="Canal de Youtube de la Facultad de Derecho">
                                    <i class="fab fa-youtube text-2"></i>
                                </a>
                            </li>
                            <li class="social-icons-pinterest">
                                <a href="http://www.pinterest.com/derechouba" target="_blank" title="Pinterest de la Facultad de Derecho">
                                    <i class="fab fa-pinterest text-2"></i>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-3764422-1', 'auto');
  ga('send', 'pageview');
</script> -->


<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-ZH1YV4P5ML"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-ZH1YV4P5ML');
</script>
    <!-- Vendor -->
<script src="/vendor/plugins/js/plugins.min.js"></script>

<!-- Link a Iconos -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- Theme Base, Components and Settings -->
<script src="/js/theme.js"></script>

<!-- Circle Flip Slideshow Script -->
<script src="/vendor/circle-flip-slideshow/js/jquery.flipshow.min.js"></script>

<!-- Current Page Views -->
<script src="/js/views/view.home.js"></script>

<!-- Current Page Vendor and Views -->
<script src="/js/views/view.contact.js"></script>

<script src="/vendor/swiped-events/swiped-events.js"></script>

<!-- Theme Custom -->
<script src="/js/main.js"></script>
<script src="/js/custom.js"></script>

<!-- Theme Initialization Files -->
<script src="/js/theme.init.js"></script>

<script>
    (function($) {

'use strict';

/*
Thumb Gallery
*/
theme.fn.intObs( '.thumb-gallery-wrapper', function(){
    var $thumbGalleryDetail = $(this).find('.thumb-gallery-detail'),
        $thumbGalleryThumbs = $(this).find('.thumb-gallery-thumbs'),
        flag = false,
        duration = 300;

    $thumbGalleryDetail
        .owlCarousel({
            items: 1,
            margin: 10,
            nav: true,
            dots: false,
            loop: true,
            autoHeight: true,
            navText: [],
            rtl: ( $('html').attr('dir') == 'rtl' ) ? true : false
        })
        .on('changed.owl.carousel', function(e) {
            if (!flag) {
                flag = true;
                $thumbGalleryThumbs.trigger('to.owl.carousel', [e.item.index-1, duration, true]);

                $thumbGalleryThumbs.find('.owl-item').removeClass('selected');
                $thumbGalleryThumbs.find('.owl-item').eq( e.item.index ).addClass('selected');
                flag = false;
            }
        });

    
    $thumbGalleryThumbs
        .owlCarousel({
            margin: 15,
            items: $(this).data('thumbs-items') ? $(this).data('thumbs-items') : 4,
            nav: false,
            center: $(this).data('thumbs-center') ? true : false,
            dots: false,
            rtl: ( $('html').attr('dir') == 'rtl' ) ? true : false
        })
        .on('click', '.owl-item', function() {
            $thumbGalleryDetail.trigger('to.owl.carousel', [$(this).index(), duration, true]);
        })
        .on('changed.owl.carousel', function(e) {
            if (!flag) {
                flag = true;
                $thumbGalleryDetail.trigger('to.owl.carousel', [e.item.index, duration, true]);
                flag = false;
            }
        });

    $thumbGalleryThumbs.find('.owl-item').eq(0).addClass('selected');
}, {});

}).apply(this, [jQuery]);
</script>
</body>

</html>