<!DOCTYPE html>
<html lang="es">
<head>
    

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="author" content="kame-code.com">
<meta name="robots" content="index,follow">

<meta property="og:image" content="/img/logo/logo-media.png">
<meta property="og:image:type" content="image/png">
<meta property="og:image:width" content="363">
<meta property="og:image:height" content="363">

<!-- Mobile Specific Meta Tag-->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<!-- X TWITTER-->

<!-- Favicon and Apple Icons-->
<link rel="apple-touch-icon" sizes="57x57" href="/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon/favicon-16x16.png">
<link rel="manifest" href="/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<!-- Web Fonts  -->
<link id="googleFonts" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800%7CShadows+Into+Light&display=swap" rel="stylesheet" type="text/css">

<!-- Vendor CSS -->
<link rel="stylesheet" href="/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="/vendor/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="/vendor/animate/animate.compat.css">
<link rel="stylesheet" href="/vendor/simple-line-icons/css/simple-line-icons.min.css">
<link rel="stylesheet" href="/vendor/owl.carousel/assets/owl.carousel.min.css">
<link rel="stylesheet" href="/vendor/owl.carousel/assets/owl.theme.default.min.css">
<link rel="stylesheet" href="/vendor/magnific-popup/magnific-popup.min.css">

<!-- Theme CSS -->
<link rel="stylesheet" href="/css/theme.css">
<link rel="stylesheet" href="/css/theme-elements.css">
<link rel="stylesheet" href="/css/theme-blog.css">
<link rel="stylesheet" href="/css/theme-shop.css">

<!-- Skin CSS -->
<link id="skinCSS" rel="stylesheet" href="/css/skins/derecho.css">

<!-- Theme Custom CSS -->
<link rel="stylesheet" href="/css/custom.css?1682693634">

<!-- Head Libs -->
<script src="/vendor/modernizr/modernizr.min.js"></script>

<base href="https://www.derecho.uba.ar" />
    <meta name="description" content="Facultad de Derecho de la Universidad de Buenos Aires">
    <title>Proyectos UBACyT - Investigaci&oacute;n | Facultad de Derecho - Universidad de Buenos Aires</title>
</head>
<body class="cbp-spmenu-push">
    <div class="container">
        <nav id="menu-offcanvas" class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left">
            <h3>Secretar&iacute;a de Investigaci&oacute;n<a class="glyphicon glyphicon-remove" id="hideLeftPush"></a></h3>
            <ul class="nav nav-list flex-column mb-5"><li class="nav-item"><a href="investigacion/inv_institutos.php" class="nav-link">Institutos de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_proyectos_vigentes.php" class="nav-link">Proyectos de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_becarios.php" class="nav-link">Becarios/as de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_programas_estudiantes.php" class="nav-link">Programas para estudiantes</a></li>
<li class="nav-item"><a href="investigacion/inv_programas_docentes_investigadores.php" class="nav-link">Programas para docentes-investigadores/as</a></li>
<li class="nav-item"><a href="investigacion/investigacion_investigadores_visitantes.php" class="nav-link">Investigadores/as visitantes</a></li>
<li class="nav-item"><a href="investigacion/agenda/" class="nav-link">Agenda</a></li>
<li class="nav-item"><a href="investigacion/noticias/" class="nav-link">Noticias</a></li>
</ul><h5 class=" text-2 pt-4">Contacto</h5>
    <ul class="list list-icons list-icons-style-2 mt-2">
        <li><i class="fas fa-map-marker-alt top-6"></i>Primer Piso</li>
        <li><i class="fas fa-clock top-6"></i>Lunes a viernes 10 a 20 hs (atención telefónica) - Lunes a viernes 10 a 19 hs (atención presencial)</li>
        <li><i class="fas fa-phone top-6"></i> (5411) 5287-7096</li>
        <li><i class="fas fa-envelope top-6"></i> <a href="mailto:investigacion@derecho.uba.ar">investigacion@derecho.uba.ar</a></li>
    </ul>
<h5 class="text-2 pt-4">Redes</h5>
    <ul class="social-icons">
        <li class="social-icons-twitter"><a href="http://twitter.com/SI_DerechoUBA  " target="_blank"><i class="fab fa-twitter"></i></a></li>
        <li class="social-icons-instagram"><a href="https://www.instagram.com/si_derechouba/  " target="_blank"><i class="fab fa-instagram"></i></a></li>
        <li class="social-icons-youtube"><a href="https://www.youtube.com/channel/UCFz7MFrOGcFxkQbrItItzTw  " target="_blank"><i class="fab fa-youtube"></i></a></li>
    </ul>        </nav>
        
                <header id="header">
    <div class="header-top">
        <div class="row">

		
            <div class="col-lg-6 col-md-4 col-sm-4">
		<!--	<img src="/imagenes/logo-uba-200.png" alt="200 años UBA" style="width: 64px; margin-left:3px;">-->
                <a href="/" title="Facultad de Derecho - UBA"><img src="imagenes/banner-negro.png" class="banner" style="margin-left:3px;"></a>
                <button type="button" id="showLeftPush" class="navbar-toggle navbar-toggle-aside-menu">
                    <span class="fa fa-outdent"></span>
                </button>
                <button type="button" class="navbar-toggle open-collapse" data-toggle="collapse" data-target=".menu-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>

            <nav class="col-lg-6 col-md-8 col-sm-8 perfiles">
                <ul class="list-inline float-right">
                    <li class="list-inline-item">
                        <a title="Sector Ingresantes - Facultad de Derecho" href="ingresantes">Ingresantes</a>
                    </li>
                    <li class="list-inline-item">
                        <a title="Sector Alumnos - Facultad de Derecho" href="/estudiantes/">Estudiantes</a>
                    </li>
                    <li class="list-inline-item">
                        <a title="Sector Docentes - Facultad de Derecho" href="docentes">Docentes</a>
                    </li>
                    <li class="list-inline-item">
                        <a title="Sector Graduados - Facultad de Derecho" href="graduados">Graduadas/os</a>&nbsp;&nbsp;
                    </li>
                </ul>
            </nav>
            <!-- search -->

            <form class="search hidden-xs" action="/index_resbus.php" id="cse-search-box" accept-charset="utf-8">
                <input type="hidden" name="cx" value="007910097264156725590:4u2nbtj2ado">
                <input type="hidden" name="cof" value="FORID:11">
                <input type="hidden" name="ie" value="utf-8">
                <input type="text" class="form-control boton-goo1" name="q" placeholder="Buscar...">
                <span class="fa fa-search"></span>
            </form>
            <!-- /search -->
            
            <div class="navbar-collapse menu-collapse collapse">
                <ul class="nav navbar-nav">
                    <li><a href="/institucional">Institucional</a></li>
                    <li><a href="/academica">Académica</a></li>
                    <li><a href="/investigacion">Investigación</a></li>
                    <li><a href="/extension">Extensión</a></li>
                    <li><a href="/internacionales">Internacionales</a></li>
                    <li><a href="/publicaciones">Publicaciones</a></li>
                    <li><a href="/biblioteca">Biblioteca</a></li>
                    <li><a href="/academica/posgrados">Posgrado</a></li>
                </ul>
                <div class="visible-xs">        
                    <form class="search" action="/index_resbus.php" id="cse-search-box" accept-charset="utf-8">
                        <input type="hidden" name="cx" value="007910097264156725590:4u2nbtj2ado">
                        <input type="hidden" name="cof" value="FORID:11">
                        <input type="hidden" name="ie" value="utf-8">
                        <input type="text" class="form-control boton-goo1" name="q" placeholder="Buscar...">
                        <span class="fa fa-search"></span>
                    </form>
                    <!--
                    <form action="/index_resbus.php" id="cse-search-box" accept-charset="utf-8">
                        <input type="hidden" name="cx" value="007910097264156725590:4u2nbtj2ado">
                        <input type="hidden" name="cof" value="FORID:11">
                        <input type="hidden" name="ie" value="utf-8">
                        <div class="input-group input-group-sm">
                            <input type="text" class="form-control" placeholder="Buscar" name="q">
                            <div class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <span class="glyphicon glyphicon-search"></span>
                                </button>
                            </div>
                        </div>
                    </form>
                    -->
                </div>
            </div>

        </div>
    </div>
    <div class="menu">
        <div class="row">
            <nav class="col-md-12">
                <ul class="list-inline d-flex justify-content-around">
                    <li class="list-inline-item text-center">
                        <a title="Facultad de Derecho" href="institucional">Institucional</a>
                    </li>
                    <li class="list-inline-item text-center">
                        <a title="Carreras, posgrados, formación docente" href="academica">Académica</a>
                    </li>
                    <li class="list-inline-item text-center">
                        <a title="Institutos de investigación, proyectos de investigación" href="investigacion">Investigación</a>
                    </li>
                    <li class="list-inline-item text-center">
                        <a title="Cursos, becas, deportes" href="extension">Extensión</a>
                    </li>
                    <li class="list-inline-item text-center">
                        <a title="Cooperación internacional de la Facultad de Derecho" href="internacionales">Internacionales</a>
                    </li>
                    <li class="list-inline-item text-center">
                        <a title="Publicaciones periódicas, libros, revistas" href="publicaciones">Publicaciones</a>
                    </li>
                    <li class="list-inline-item text-center">
                        <a title="Préstamos, libros electrónicos, catálogos" href="biblioteca">Biblioteca</a>
                    </li>
                    <li class="list-inline-item text-center">
                        <a title="Doctorado, posdoctorado, maestrías" href="academica/posgrados">Posgrado</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</header>                
        <nav class="MenuSector">
            <div class="pull-left sector">
                <a class="location" href="/investigacion/">Investigaci&oacute;n</a>
            </div>
            <ol class="breadcrumb pull-right hidden-xs">
                <li><a href="index.php">Inicio</a></li><li><a href="/investigacion/">Investigacion</a></li><li><a href="investigacion/inv_proyectos_vigentes.php">Proyectos de Investigaci&oacute;n vigentes</a></li><li><a href="investigacion/inv_prog_ubacyt.php">Proyectos UBACyT 2010-2012</a></li><li><a href="investigacion/en-inv_proyectos_vigentes_ubacyt_2013_alegre-gargarella.php" title="information for foreigners">English version</a></li>
            </ol>
            <div class="clearfix"></div>
        </nav>
        
        <section class="row">
            <div class="col-lg-3 col-md-3 col-sm-4 menu_izq hidden-xs">
                <p>Secretar&iacute;a de Investigaci&oacute;n</p>
                <nav>
                    <ul class="nav nav-list flex-column mb-5"><li class="nav-item"><a href="investigacion/inv_institutos.php" class="nav-link">Institutos de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_proyectos_vigentes.php" class="nav-link">Proyectos de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_becarios.php" class="nav-link">Becarios/as de Investigación</a></li>
<li class="nav-item"><a href="investigacion/inv_programas_estudiantes.php" class="nav-link">Programas para estudiantes</a></li>
<li class="nav-item"><a href="investigacion/inv_programas_docentes_investigadores.php" class="nav-link">Programas para docentes-investigadores/as</a></li>
<li class="nav-item"><a href="investigacion/investigacion_investigadores_visitantes.php" class="nav-link">Investigadores/as visitantes</a></li>
<li class="nav-item"><a href="investigacion/agenda/" class="nav-link">Agenda</a></li>
<li class="nav-item"><a href="investigacion/noticias/" class="nav-link">Noticias</a></li>
</ul><h5 class=" text-2 pt-4">Contacto</h5>
    <ul class="list list-icons list-icons-style-2 mt-2">
        <li><i class="fas fa-map-marker-alt top-6"></i>Primer Piso</li>
        <li><i class="fas fa-clock top-6"></i>Lunes a viernes 10 a 20 hs (atención telefónica) - Lunes a viernes 10 a 19 hs (atención presencial)</li>
        <li><i class="fas fa-phone top-6"></i> (5411) 5287-7096</li>
        <li><i class="fas fa-envelope top-6"></i> <a href="mailto:investigacion@derecho.uba.ar">investigacion@derecho.uba.ar</a></li>
    </ul>
<h5 class="text-2 pt-4">Redes</h5>
    <ul class="social-icons">
        <li class="social-icons-twitter"><a href="http://twitter.com/SI_DerechoUBA  " target="_blank"><i class="fab fa-twitter"></i></a></li>
        <li class="social-icons-instagram"><a href="https://www.instagram.com/si_derechouba/  " target="_blank"><i class="fab fa-instagram"></i></a></li>
        <li class="social-icons-youtube"><a href="https://www.youtube.com/channel/UCFz7MFrOGcFxkQbrItItzTw  " target="_blank"><i class="fab fa-youtube"></i></a></li>
    </ul>                </nav>
            </div>
    
            <div class="contenido_pagina-col2 col-lg-9 col-md-9 col-sm-8">
                
   <h1>Proyectos UBACyT</h1>
   <h3>Fecha de inicio </h3>
   <p class="tabulado">01/07/2013</p>
   <h3>Fecha de finalizaci&oacute;n </h3>
   <p class="tabulado">31/12/2015</p>
   <h3>C&oacute;digo </h3>
   <p class="tabulado">    20020120200377BA</p>
   <h3>Tipo de proyecto </h3>
   <p class="tabulado">Grupo en Formaci&oacute;n</p>
   <h3>T&iacute;tulo</h3>
   <p class="tabulado">Principio de autonom&iacute;a, libertad de conciencia y libertad religiosa.</p>
   <h3>Director</h3>
   <p class="tabulado">Alegre, Marcelo</p>
   <h3>Codirector</h3>
   <p class="tabulado">Gargarella, Roberto</p>
   <h3>Contacto</h3>
   <p class="tabulado"><a href="mailto:alegre@derecho.uba.ar">alegre@derecho.uba.ar</a></p>
   <p>&nbsp;</p>
   <div class="table-responsive"><table class="table table-striped table-bordered"><thead><tr class="celeste">
         <th colspan="2" align="center"><strong>INTEGRANTES</strong></th>
        </tr></thead><tbody><tr>
         <td align="center" valign="middle" width="16%"><strong>N&deg;</strong></td>
         <td align="center" valign="middle"><strong>Nombre y apellido</strong></td>
        </tr><tr>
         <td align="center" valign="middle">1</td>
         <td align="center" valign="middle">Romina Andrea Faerman<br /></td>
        </tr><tr>
         <td align="center" valign="middle">2</td>
         <td align="center" valign="middle">Hernan Victor Gullco<br /></td>
        </tr><tr>
         <td align="center" valign="middle">3</td>
         <td align="center" valign="middle">Nahuel Maisley<br /></td>
        </tr><tr>
         <td align="center" valign="middle">4</td>
         <td align="center" valign="middle">Ingnacio Mastroleo<br /></td>
        </tr><tr>
         <td align="center" valign="middle">5</td>
         <td align="center" valign="middle">Ezequiel Horacio Monti<br /></td>
        </tr><tr>
         <td align="center" valign="middle">6</td>
         <td align="center" valign="middle">Carla Vanina Maenza<br /></td>
        </tr><tr>
         <td align="center" valign="middle">7</td>
         <td align="center" valign="middle">Federico Daniel Orlando</td>
        </tr><tr>
         <td align="center" valign="middle">8</td>
         <td align="center" valign="middle">Florencia Luna<br /></td>
       </tr><tr>
         <td align="center" valign="middle">9</td>
         <td align="center" valign="middle">Lautaro Furfaro<br /></td>
       </tr><tr>
         <td align="center" valign="middle">10</td>
         <td align="center" valign="middle">Eduardo Enrique Rivera Lopez<br /></td>
       </tr>
       <tr>
         <td align="center" valign="middle">11</td>
         <td align="center" valign="middle">Patricio Enrique Kenny</td>
       </tr>
       </tbod></table></div>
   <p><strong>PALABRAS CLAVE</strong></p>
   <p class="tabulado">Principio de Autonom&iacute;a<br />
    Libertad de Conciencia<br />
    Libertad Religiosa</p>
   <p><strong>RESUMEN</strong></p>
   <p class="tabulado">  El proyecto tiene dos objetivos: (1) enriquecer la interpretaci&oacute;n de los principios constitucionales que protegen la libertad de conciencia, particularmente en relaci&oacute;n con el principio de autonom&iacute;a; y (2) fundamentar la necesidad o no de promover reformas legales y/o constitucionales para armonizar ambos principios. (1) Si bien existen precedentes judiciales que buscan compatibilizar la libertad de conciencia y la libertad religiosa con una noci&oacute;n robusta de autonom&iacute;a, existen zonas de incertidumbre. Nos centraremos en tres cuestiones: (a) El sostenimiento de la religi&oacute;n cat&oacute;lica: Existen interpretaciones amplias y restrictivas en torno del alcance del art&iacute;culo 2 CN. La hip&oacute;tesis del proyecto es que la lectura restrictiva, si bien es la m&aacute;s plausible, resulta indeterminada, y que la forma de darle un contenido m&aacute;s preciso es articular esta cl&aacute;usula con el resto de la CN, en especial, con las reformas igualitarias y antidiscriminatorias introducidas en 1994. (b) La cuesti&oacute;n de la educaci&oacute;n religiosa: Partimos del fallo Castillo c. Salta para preguntarnos, &iquest;cu&aacute;les son los requisitos que deber&iacute;a respetar la educaci&oacute;n religiosa en las escuelas p&uacute;blicas para ser aceptable constitucionalmente? &iquest;Son estos requisitos implementables? Nuestra hip&oacute;tesis es que la clave del problema radica en los (tal vez insuperables) recaudos que la educaci&oacute;n religiosa debe cubrir para que se implemente sin discriminaciones y sin erosionar principios de educaci&oacute;n democr&aacute;tica. (c) Objeci&oacute;n de conciencia en el terreno de la salud sexual y reproductiva: Proponemos centrar el an&aacute;lisis en las consecuencias del reciente fallo FAL de la CSJN. Nuestra hip&oacute;tesis es que la sentencia sustenta una noci&oacute;n robusta de la objeci&oacute;n de conciencia, con un l&iacute;mite de la afectaci&oacute;n de derechos fundamentales de terceros. Nos proponemos elucidar las pautas para el procedimiento a seguir para eximir a los objetores de sus deberes. (2) Nuestra hip&oacute;tesis respecto del segundo objetivo es que es posible, a partir del material interpretativo disponible, combinar las exigencias de la libertad de conciencia y el principio de autonom&iacute;a, de forma compatible con los desarrollos m&aacute;s convincentes del liberalismo pol&iacute;tico. Sin perjuicio de ello, creemos que, eventualmente, podr&iacute;an realizarse ciertos ajustes en la normativa a los efectos de solucionar ciertas ambig&uuml;edades que pueden debilitar el arribo a las soluciones m&aacute;s favorables en t&eacute;rminos de igualdad religiosa, libertad de conciencia y autonom&iacute;a personal.</p>

   
   
  
            </div>
        </section>
    </div>
    
    
    <footer id="footer">
        <div class="container footer">
            <div class="row">
                <!-- Footer Content -->
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="de-interes">
                      <h3 class="h6 subrayado text-uppercase">Accesos directos</h3>
                        <ul class="list-unstyled interes" style="margin-bottom:0">
                            <li><i class="fa fa-circle"></i><a title="Consejo Directivo de la Facultad de Derecho" href="institucional/consejo-directivo/">Consejo Directivo</a></li>
                            <li><i class="fa fa-circle"></i><a href="investigacion/inv_proyectos_vigentes.php">Proyectos de investigaci&oacute;n</a></li>
                            <li><i class="fa fa-circle"></i><a title="Programas de intercambio" href="internacionales/programas-de-intercambio-estudiantil.php">Programas de intercambio estudiantil</a></li>
                            <li><i class="fa fa-circle"></i><a title="Carrera y Formaci&oacute;n Docente" href="academica/carrdocente/">Carrera Docente</a></li>
                            <li><i class="fa fa-circle"></i><a href="internacionales/ciclo-de-cursos-on-line/">Ciclo de cursos online (CCO)</a></li>
                            <li><i class="fa fa-circle"></i><a title="Observatorios y Centros de Estudios de la Facultad de Derecho" href="institucional/observatorios-y-centros-de-estudios.php">Observatorios y Centros de Estudios</a></li>
                            <li><i class="fa fa-circle"></i><a href="extension/programas-de-extension-universitaria.php">Programas de extensión</a></li>
                            <li><i class="fa fa-circle"></i><a title="Ciclo de Grandes Conciertos" href="extension/conciertos.php">Ciclo de Grandes Conciertos</a></li                          <li><i class="fa fa-circle"></i><a title="Cursos de extensión" href="extension/cursos">Cursos de extensión</a></li>
                            <li><i class="fa fa-circle"></i><a title="Programa de becas" href="extension/becas/">Programa de becas</a></li>
                            <li><i class="fa fa-circle"></i><a title="Informes" href="institucional/deinteres/informes-de-gestion.php">Informes de gestión</a></li>
                        </ul>
                    </div>
                </div>
                <!-- End Footer Content -->

                <!-- Footer Content -->
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="comunicacion">
                        <h3 class="h6 subrayado text-uppercase">Comunicación</h3>
                        <ul class="list-unstyled mb-4">
                            <li>
                                <h4 class="h6 mb-0"><a href="derechoaldia">Derecho al Día</a></h4>
                            </li>
                            <li>
                                <h4 class="h6 mb-0"><a href="noticias">Noticias</a></h4>
                            </li>
                            <li>
                                <h4 class="h6 mb-0"><a href="institucional/derechoenradiouba/">Derecho en Radio UBA</a></h4>
                            </li>
                        </ul>

                       <a href="https://www.facebook.com/DerechoUBA" target="_blank"><span class="fa fa-facebook color-facebook social"></span></a>
                       <a href="https://www.x.com/DerechoUBA" target="_blank"><span class="fa fa-twitter color-twitter social"></span></a>
                       <a href="https://www.instagram.com/fduba/" target="_blank"><span class="fa fa-instagram color-instagram social"></span></a>
                       <a href="https://www.youtube.com/user/DerechoUBA" target="_blank"><span class="fa fa-youtube-play color-youtube social"></span></a>
					   <a href="http://www.pinterest.com/derechouba" target="_blank"><span class="fa fa-pinterest color-youtube social"></span></a>
                    </div>
                </div>
                <!-- End Footer Content -->

                <!-- Footer Content -->
                <div class="col-lg-4 col-md-4 col-sm-12">
                    <div class="direcciones-utiles">
                        <h3 class="h6 subrayado text-uppercase">Direcciones útiles</h3>
                        <ul class="list-unstyled">
                            <li class="mb-1"><strong>Estudiantes |</strong> <a href="mailto:diralumnos@derecho.uba.ar" title="Mail Direccion de Alumnos">diralumnos@derecho.uba.ar</a></li>
                            <li class="mb-1"><strong>Igualdad de g&eacute;nero</strong> | <a href="mailto:areageneroest@derecho.uba.ar">areageneroest@derecho.uba.ar</a></li>
                            <li class="mb-1"><strong>Posgrado |</strong> <a href="mailto:posgrado@derecho.uba.ar">posgrado@derecho.uba.ar</a></li>
                            <li class="mb-1"><strong>Extensión |</strong> <a href="mailto:eextensionuniversitaria@derecho.uba.ar">extensionuniversitaria@derecho.uba.ar</a></li>
                            <li class="mb-1"><strong>Investigación |</strong> <a href="mailto:investigacion@derecho.uba.ar">investigacion@derecho.uba.ar</a></li>
                            <li class="mb-1"><strong>Internacionales |</strong> <a href="mailto:internacionales@derecho.uba.ar">internacionales@derecho.uba.ar</a></li>
                            <li><strong>Institucionales |</strong> <a href="mailto:institucionales@derecho.uba.ar">institucionales@derecho.uba.ar</a></li>  
                            <li class="mb-1"><strong>Publicaciones |</strong>&nbsp;<a href="mailto:dpublica@derecho.uba.ar">dpublica@derecho.uba.ar</a></li>
                            <li class="mb-1"><strong>Biblioteca |</strong> <a href="mailto:biblio@derecho.uba.ar">biblio@derecho.uba.ar</a></li>
                        </ul>
                        <p><a class="btn bg-1 btn-sm" href="index_contactenos.php">Ver directorio completo</a></p>
                    </div>
                </div>
                <!-- End Footer Content -->
            </div>
        </div>
        <div class="footer-info">
            <div class="container">
              <small class="">Facultad de Derecho | <a target="_blank" href="http://www.uba.ar" class="color-1">Universidad de Buenos Aires</a></small> | <small class="">Av. Figueroa Alcorta 2263, CABA | 5287-6700</small>
            </div>
        </div>
    </footer>

    <script>
        /*
        $('a').each(function () {
            var href = $(this).attr('href'), hashes, hash = '';
            if (href) {
                var queryString = (href.indexOf('?') !== -1) ? '&new' : '?new';
                if (hashes = href.match(/#[a-z0-9]+/gi)) {
                    hash = hashes[0];
                    href = href.replace(hash, '');
                }
                $(this).attr('href', href + queryString + hash);
            }
        });
        
        $('.menu_izq nav').affix({
          offset: {
            top: 210,
            bottom: function () {
                return (this.bottom = $('#footer').outerHeight(true))
            }
          }
        });
        */
    </script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-3764422-1', 'auto');
  ga('send', 'pageview');

</script></body>
</html>
